\set ON_ERROR_STOP on
BEGIN;
CREATE SCHEMA healthnews_exp_20261010;
CREATE TABLE healthnews_exp_20261010.health_articles_chunks AS TABLE public.health_articles_chunks;
CREATE UNIQUE INDEX healthnews_exp_20261010_pk ON healthnews_exp_20261010.health_articles_chunks (id);
CREATE INDEX healthnews_exp_20261010_hnsw ON healthnews_exp_20261010.health_articles_chunks USING hnsw (embedding_half halfvec_cosine_ops);
GRANT USAGE ON SCHEMA healthnews_exp_20261010 TO care_app;
GRANT SELECT ON healthnews_exp_20261010.health_articles_chunks TO care_app;
COMMIT;
ANALYZE healthnews_exp_20261010.health_articles_chunks;
SELECT json_build_object('snapshot_table','healthnews_exp_20261010.health_articles_chunks','count',count(*),'id_digest',md5(string_agg(id,',' ORDER BY id))) FROM healthnews_exp_20261010.health_articles_chunks;
