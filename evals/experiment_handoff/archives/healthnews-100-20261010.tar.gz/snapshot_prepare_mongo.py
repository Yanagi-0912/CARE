"""新庫快照建立稿。預設只印計畫；--create 需要使用者明確批准。"""
import argparse,asyncio,gzip,hashlib,json,pathlib
TARGET='healthnews_exp_20261010_new'
PG_TABLE='healthnews_exp_20261010.health_articles_chunks'

def hashed_docs(docs):
 h=hashlib.sha256()
 for doc in docs:h.update(json.dumps(doc,ensure_ascii=False,sort_keys=True,default=str).encode()+b'\n')
 return h.hexdigest()

async def create(out):
 from app.core.config import settings as s
 from motor.motor_asyncio import AsyncIOMotorClient
 from pymongo.operations import SearchIndexModel
 import asyncpg
 client=AsyncIOMotorClient(s.MONGODB_URI,serverSelectionTimeoutMS=20000)
 pg=None
 try:
  db=client[s.MONGODB_DB]
  if TARGET in await db.list_collection_names():raise ValueError('target exists; refusing to overwrite')
  source=db[s.MONGODB_COLLECTION]
  indexes=await source.list_search_indexes(s.MONGODB_TEXT_INDEX).to_list(None)
  if not indexes or not indexes[0].get('queryable'):raise ValueError('source index not queryable')
  definition=indexes[0]['latestDefinition']
  docs=await source.find({}).sort('_id',1).to_list(None)
  if not docs:raise ValueError('source is empty')
  pg=await asyncpg.connect(s.PGVECTOR_DSN,timeout=10)
  pg_rows=await pg.fetch(f'SELECT id, {s.PGVECTOR_VECTOR_COLUMN}::text AS embedding FROM {PG_TABLE} ORDER BY id')
  if [str(d['_id']) for d in docs]!=[str(r['id']) for r in pg_rows]:
   raise ValueError('PG snapshot and Mongo source IDs differ; no Mongo clone created')
  target=await db.create_collection(TARGET)
  for start in range(0,len(docs),500):await target.insert_many(docs[start:start+500],ordered=True)
  copied=await target.find({}).sort('_id',1).to_list(None)
  live_after=await source.find({}).sort('_id',1).to_list(None)
  source_hash=hashed_docs(docs)
  if hashed_docs(copied)!=source_hash or hashed_docs(live_after)!=source_hash:
   raise ValueError('source changed during snapshot or clone mismatch; leave target for inspection')
  await target.create_search_index(SearchIndexModel(name=s.MONGODB_TEXT_INDEX,definition=definition))
  out.mkdir(parents=True,exist_ok=True)
  with gzip.open(out/'mongo_snapshot.jsonl.gz','wt',encoding='utf-8') as f:
   for d in copied:f.write(json.dumps(d,ensure_ascii=False,sort_keys=True,default=str)+'\n')
  h=hashlib.sha256()
  with gzip.open(out/'pg_snapshot_vectors.jsonl.gz','wt',encoding='utf-8') as f:
   for r in pg_rows:
    line=json.dumps([str(r['id']),r['embedding']],ensure_ascii=False)+'\n';h.update(line.encode());f.write(line)
  manifest={'snapshot_id':'healthnews_new_20261010','status':'pending_search_index_readiness',
   'mongo_collection':TARGET,'mongo_search_index':s.MONGODB_TEXT_INDEX,'pg_table':PG_TABLE,
   'mongo_sha256':source_hash,'pg_sha256':h.hexdigest(),'mongo_count':len(copied),'pg_count':len(pg_rows),
   'source_unchanged_during_copy':True,'mongo_search_definition':definition,
   'original_collection_modified':False,'known_writers':'snapshot preparation only; experiment runner read-only'}
  (out/'snapshot_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
  print(json.dumps(manifest,ensure_ascii=False))
 finally:
  if pg:await pg.close()
  client.close()

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--create',action='store_true');p.add_argument('--out',type=pathlib.Path,default=pathlib.Path('/tmp/healthnews-new-snapshot'))
 args=p.parse_args()
 if args.create:asyncio.run(create(args.out))
 else:print(json.dumps({'approval_required':True,'mongo_target':TARGET,'pg_target':PG_TABLE,'actions':['clone only knowledge-base collection','copy existing Atlas Search definition','export snapshot documents and vectors','verify copied content and ID equality'],'production_overwrite':False,'formal_execution':'blocked until immutable snapshot readiness verified'},ensure_ascii=False,indent=2))
