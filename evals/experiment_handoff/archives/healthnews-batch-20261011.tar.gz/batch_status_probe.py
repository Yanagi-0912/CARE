"""一次性Batch診斷工具，須在CARE環境中執行；不屬於正式RAG批次入口。"""
import asyncio,json
from app.core.config import settings
from google import genai
JOBS=[{'probe_id': 'HN066-D-r1-decomposition', 'model': 'gemini-3.8-flash', 'phase': 'transport_capability_only_not_formal', 'name': 'batches/2q1r824zq8htwxex4zw7gj33aopmfv219o2z', 'state': 'JobState.JOB_STATE_PENDING', 'display_name': 'care-healthnews-batch-smoke-20261011-decomposition', 'create_time': '2026-10-11 04:44:21.089666+00:00', 'source_effective_input_sha256': '5064dc2b205f3658f8a4e881cab34b1f43ce7d7496e0948429a305ebfdc2ea7c'}, {'probe_id': 'HN001-B-r1-generation', 'model': 'gemini-3.5-flash-lite', 'phase': 'transport_capability_only_not_formal', 'name': 'batches/r6lqy43qp9en3zrct7c8pyiekx4mgo5du68g', 'state': 'JobState.JOB_STATE_PENDING', 'display_name': 'care-healthnews-batch-smoke-20261011-generation', 'create_time': '2026-10-11 04:44:28.530431+00:00', 'source_effective_input_sha256': 'b68a88411685831d40bf1e2d5cf761ca876de19ebd1e649ff5acabbf6c633869'}]
async def main():
 report=[]
 async with genai.Client(api_key=settings.GEMINI_API_KEY).aio as client:
  for record in JOBS:
   try:
    job=await client.batches.get(name=record['name'])
    out={**record,'state':str(job.state),'update_time':str(job.update_time),'end_time':str(job.end_time),'completion_stats':job.completion_stats.model_dump(mode='json') if job.completion_stats else None,'job_error':job.error.model_dump(mode='json') if job.error else None}
    if job.dest and job.dest.inlined_responses:
     out['responses']=[r.model_dump(mode='json',exclude_none=True) for r in job.dest.inlined_responses]
    elif job.dest and job.dest.file_name and str(job.state).endswith('JOB_STATE_SUCCEEDED'):
     out['responses_jsonl']=(await client.files.download(file=job.dest.file_name)).decode()
    report.append(out)
   except Exception as exc:report.append({**record,'status_check_error':type(exc).__name__,'code':getattr(exc,'code',None)})
 print(json.dumps(report,ensure_ascii=False,default=str))
asyncio.run(main())
