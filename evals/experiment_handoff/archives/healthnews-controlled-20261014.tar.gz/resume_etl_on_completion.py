"""Restore the original ETL suspend flag after this exact experiment Job completes."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

ANNOTATION = 'experiments.care/config-version'

def stamp(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))

def eligible(job, state):
    meta = job.get('metadata', {})
    try:
        return (meta.get('name') == state['experiment_job']
                and meta.get('namespace') == state['namespace']
                and meta.get('annotations', {}).get(ANNOTATION) == state['config_version']
                and stamp(meta['creationTimestamp']) >= stamp(state['paused_at'])
                and not any(c.get('type') == 'Failed' and c.get('status') == 'True' for c in job.get('status', {}).get('conditions', []))
                and any(c.get('type') == 'Complete' and c.get('status') == 'True' for c in job.get('status', {}).get('conditions', [])))
    except (KeyError, ValueError, TypeError):
        return False

def kubectl(*args, payload=None):
    result = subprocess.run(['/usr/local/bin/k3s', 'kubectl', *args], input=payload,
                            text=True, capture_output=True, timeout=30)
    if result.returncode:
        raise RuntimeError('kubectl operation failed')
    return result.stdout

def main(path):
    state = json.loads(path.read_text())
    if state['status'] == 'RESUMED':
        return
    raw = kubectl('get', 'job', state['experiment_job'], '-n', state['namespace'], '--ignore-not-found', '-o', 'json')
    if not raw.strip() or not eligible(json.loads(raw), state):
        return
    cron = json.loads(kubectl('get', 'cronjob', state['cronjob'], '-n', state['namespace'], '-o', 'json'))
    if cron['metadata']['uid'] != state['cronjob_uid']:
        raise RuntimeError('CronJob identity changed; refusing automatic restore')
    if cron['spec'].get('suspend', False) != state['original_suspend']:
        patch = [{'op': 'test', 'path': '/metadata/uid', 'value': state['cronjob_uid']},
                 {'op': 'test', 'path': '/spec/suspend', 'value': True},
                 {'op': 'replace', 'path': '/spec/suspend', 'value': state['original_suspend']}]
        kubectl('patch', 'cronjob', state['cronjob'], '-n', state['namespace'], '--type=json', '--patch-file=/dev/stdin', payload=json.dumps(patch))
    check = json.loads(kubectl('get', 'cronjob', state['cronjob'], '-n', state['namespace'], '-o', 'json'))
    if check['metadata']['uid'] != state['cronjob_uid'] or check['spec'].get('suspend', False) != state['original_suspend']:
        raise RuntimeError('CronJob restore verification failed')
    state.update(status='RESUMED', resumed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    temporary = path.with_suffix('.tmp')
    with temporary.open('w') as stream:
        json.dump(state, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    print('ETL schedule restored after matching experiment completion')

if __name__ == '__main__':
    main(Path(sys.argv[1]))
