#!/usr/bin/env bash
set -euo pipefail
exec ssh -N \
  -o BatchMode=yes \
  -o ExitOnForwardFailure=yes \
  -o ServerAliveInterval=30 \
  -o StrictHostKeyChecking=yes \
  -o HostKeyAlias=compute.5726031482716724999 \
  -o UserKnownHostsFile=/home/york/.ssh/google_compute_known_hosts \
  -i /home/york/.ssh/google_compute_engine \
  -L 127.0.0.1:15432:10.43.78.123:5432 \
  york@34.81.224.43
