"""唯讀本機就緒性核對；不呼叫外部模型、不執行實驗、不修改資料庫。"""
import ast
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
WORKSPACE = OUT.parents[1]
REPO = WORKSPACE / "CARE"
BASE = WORKSPACE / "experiments/healthnews-100-20261010"
os.chdir(REPO)
sys.path.insert(0, str(REPO))

from app.core.config import settings
from app.services.rag.question_decomposer import looks_compound
from scripts.healthnews_experiment import build_components


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args, repo=REPO):
    env = dict(os.environ, GIT_ALTERNATE_OBJECT_DIRECTORIES=str(REPO / ".git/objects"),
               GIT_NO_LAZY_FETCH="1")
    return subprocess.check_output(["git", "-C", str(repo), *args], env=env, text=True).strip()


def read(path):
    return json.loads(path.read_text())


dataset_path = BASE / "CARE_Healthnews_100_Review_v3.json"
dataset = read(dataset_path)
cases = dataset["cases"]
questions = {c["id"]: c["question"] for c in cases}
remote_repo = Path("/tmp/care-readiness-20261011-remote")
remote_source = git("show", "FETCH_HEAD:app/services/rag/question_decomposer.py", repo=remote_repo)
tree = ast.parse(remote_source)
# 僅取遠端規則閘的常數與純函式，不匯入或執行遠端模組。
nodes = [n for n in tree.body if
         (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "MIN_QUESTION_MARKS" for t in n.targets))
         or (isinstance(n, ast.FunctionDef) and n.name == "looks_compound")]
scope = {}
exec(compile(ast.Module(body=nodes, type_ignores=[]), "remote_gate_only", "exec"), scope)
remote_gate = scope["looks_compound"]
keys = ["MODEL_NAME", "RAG_GENERATE_MODEL_NAME", "EMBEDDING_MODEL", "RAG_HYBRID_ENABLED",
        "RAG_CRAG_ENABLED", "RAG_COMPOUND_DECOMPOSE_ENABLED", "MONGODB_DB", "MONGODB_COLLECTION",
        "MONGODB_TEXT_INDEX", "PGVECTOR_TABLE", "PGVECTOR_VECTOR_COLUMN", "RAG_WEB_FALLBACK_ENABLED",
        "RAG_RETRIEVE_CANDIDATES", "RAG_RERANK_TOP_N", "RAG_ANSWER_TIMEOUT_SECONDS"]
local_settings = {k: getattr(settings, k) for k in keys}
historical_manifest = read(BASE / "pilot_v2/pilot/manifest.json")
historical_settings = {**historical_manifest["settings"], **historical_manifest["models"]}
if (all(getattr(settings, k, "") for k in
        ("GEMINI_API_KEY", "COHERE_API_KEY", "PGVECTOR_DSN", "MONGODB_URI", "MONGODB_TEXT_INDEX"))
        and settings.RAG_HYBRID_ENABLED and settings.RAG_CRAG_ENABLED):
    raise RuntimeError("設定已具備建立 client 的條件；先重新檢視離線保證，不執行 build_components")
try:
    build_components({})
except ValueError as exc:
    # 已確認程式在建立任何外部 client 之前以設定檢查失敗。
    local_preflight = {"status": "FAIL", "error": str(exc)}
else:
    raise RuntimeError("本機設定已變更；停止此檢查，重新檢視離線保證")

evidence = {
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "scope": "readiness_only_no_paid_requests",
    "input_version_confirmation": "pending_user_no_formal_baseline_selected",
    "handoff": {"zip_found": False, "txt_found": False,
                "searched": ["/home/york/CARE", "/tmp", "/home/york/Downloads",
                             "/mnt/data", "/mnt/c/Users/York/Downloads",
                             "/mnt/c/Users/York/Desktop", "/mnt/c/Users/York/Documents"]},
    "git": {"local_head": git("rev-parse", "HEAD"), "branch": git("branch", "--show-current"),
            "worktree_status": git("status", "--porcelain=v1"),
            "cached_origin_main": git("rev-parse", "origin/main"),
            "remote_main_readonly_fetch": git("rev-parse", "FETCH_HEAD", repo=remote_repo),
            "merge_base": git("merge-base", git("rev-parse", "HEAD"), "FETCH_HEAD", repo=remote_repo),
            "local_only_commits": git("log", "--oneline", "53b637e1..HEAD").splitlines(),
            "remote_only_commits": git("log", "--oneline", "53b637e1..FETCH_HEAD", repo=remote_repo).splitlines(),
            "diff_local_to_remote": git("diff", "--name-status", git("rev-parse", "HEAD"), "FETCH_HEAD", repo=remote_repo).splitlines()},
    "dataset": {"path": str(dataset_path), "sha256": sha(dataset_path),
                "downloads_sha256": sha(Path("/mnt/c/Users/York/Downloads/CARE_Healthnews_100_Review_v3.json")),
                "count": len(cases), "unique_ids": len(questions),
                "expected_ids_match": set(questions) == {f"HN{i:03d}" for i in range(1, 101)},
                "types": dict(collections.Counter(c["question_type"] for c in cases)),
                "languages": dict(collections.Counter(c["language"] for c in cases)),
                "local_gate_counts": dict(collections.Counter(c["question_type"] for c in cases if looks_compound(c["question"]))),
                "remote_gate_counts": dict(collections.Counter(c["question_type"] for c in cases if remote_gate(c["question"]))),
                "special_cases": [{"id": c["id"], "type": c["question_type"],
                                   "question_marks": c["question"].count("?") + c["question"].count("？"),
                                   "local_gate": looks_compound(c["question"]),
                                   "remote_gate": remote_gate(c["question"])}
                                  for c in cases if c["id"] in ("HN026", "HN033", "HN066", "HN094")]},
    "current_local_settings": local_settings,
    "credential_presence_only": {k: bool(getattr(settings, k)) for k in
                                 ("GEMINI_API_KEY", "COHERE_API_KEY", "TYPESAFE_API_KEY", "PGVECTOR_DSN", "MONGODB_URI")},
    "local_preflight": local_preflight,
    "local_vs_historical_runtime": {k: {"local": v, "historical": historical_settings.get(k)}
                                    for k, v in local_settings.items() if v != historical_settings.get(k)},
    "runner_sha256": sha(REPO / "scripts/healthnews_experiment.py"),
    "pilots": {},
}
for label in ("pilot_v1", "pilot_v2"):
    path = BASE / label / "pilot/runs.jsonl"
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    manifest = read(path.parent / "manifest.json")
    evidence["pilots"][label] = {
        "rows": len(rows), "unique_case_arm_round": len({(r["case_id"], r["arm"], r["round"]) for r in rows}),
        "cases": sorted({r["case_id"] for r in rows}),
        "arms": dict(collections.Counter(r["arm"] for r in rows)),
        "rounds": dict(collections.Counter(r["round"] for r in rows)),
        "phases": dict(collections.Counter(r["phase"] for r in rows)),
        "snapshot_ids": list({r["snapshot_id"] for r in rows}),
        "nonterminal_events": sum(e["status"] == "started" for r in rows for e in r["events"]),
        "web_executed": sum(r["web_fallback_executed"] for r in rows),
        "question_matches_dataset": all(r["original_question"] == r["original_message"] == questions[r["case_id"]] for r in rows),
        "config_version_rows": sum("config_version" in r for r in rows),
        "runner_matches_current": manifest.get("runner_sha256") == evidence["runner_sha256"],
        "crag_review_pending": sum(e.get("independent_review_status") == "pending" for r in rows for e in r["events"] if e["kind"] == "crag"),
    }
reviews = read(BASE / "per_case_review.json")["cases"]
evidence["reviews"] = {
    "classification": dict(collections.Counter(r["classification_review"]["status"] for r in reviews)),
    "source_alignment": dict(collections.Counter(r["source_alignment_review"]["status"] for r in reviews)),
    "review_status": dict(collections.Counter(r["review_status"] for r in reviews)),
    "medical_status": dict(collections.Counter(r["medical_claim_review_status"] for r in reviews)),
    "old_coverage": dict(collections.Counter(r["kb_coverage"]["old"] for r in reviews)),
    "new_coverage": dict(collections.Counter(r["kb_coverage"]["new"] for r in reviews)),
}
evidence["batch_smoke"] = [{k: r.get(k) for k in ("probe_id", "state", "response_key_matches", "model_version")}
                            for r in read(WORKSPACE / "experiments/healthnews-batch-20261011/smoke_verification.json")]
evidence["batch_runner_status"] = read(WORKSPACE / "experiments/healthnews-batch-20261011/experiment_consolidation.json")["offline_batch_runner"]
evidence["source_hashes"] = {str(p.relative_to(REPO)): sha(p) for p in
                            [REPO / "app/services/rag/question_decomposer.py", REPO / "app/services/rag/answer_service.py",
                             REPO / "app/dependencies.py", REPO / "app/core/config.py", REPO / "app/i18n/messages.py",
                             REPO / "scripts/healthnews_experiment.py", REPO / "uv.lock"]}
(OUT / "local_evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"dataset": evidence["dataset"], "local_preflight": local_preflight,
                  "output": str(OUT / "local_evidence.json")}, ensure_ascii=False, indent=2))
