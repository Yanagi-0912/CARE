"""在現有 Pod 內唯讀檢查設定、索引與快照名稱；不呼叫模型或寫入 DB。"""
import asyncio
import hashlib
import json
from pathlib import Path
import re
from datetime import datetime, timezone

from app.core.config import settings as s


async def main():
    import asyncpg
    from motor.motor_asyncio import AsyncIOMotorClient
    result = {"recorded_at": datetime.now(timezone.utc).isoformat(), "models": {
        k: getattr(s, k) for k in ("MODEL_NAME", "RAG_GENERATE_MODEL_NAME", "EMBEDDING_MODEL")},
        "settings": {k: getattr(s, k) for k in dir(s)
                     if k.startswith(("RAG_", "MONGODB_", "PGVECTOR_", "COHERE_"))
                     and not any(x in k for x in ("KEY", "URI", "DSN", "TOKEN", "SECRET", "PASSWORD"))},
        "credential_presence_only": {k: bool(getattr(s, k, "")) for k in
                                     ("GEMINI_API_KEY", "COHERE_API_KEY", "TYPESAFE_API_KEY", "PGVECTOR_DSN", "MONGODB_URI")},
        "source_hashes": {}}
    for name in ("app/services/rag/question_decomposer.py", "app/services/rag/answer_service.py",
                 "scripts/healthnews_experiment.py", "app/dependencies.py", "app/core/config.py"):
        p = Path("/app") / name
        result["source_hashes"][name] = hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    mongo = AsyncIOMotorClient(s.MONGODB_URI, serverSelectionTimeoutMS=10000,
                              connectTimeoutMS=10000, socketTimeoutMS=15000)
    try:
        db = mongo[s.MONGODB_DB]
        names = await db.list_collection_names(filter={"name": {"$regex": "healthnews|snapshot|health_articles_chunks"}})
        col = db[s.MONGODB_COLLECTION]
        indexes = await col.list_search_indexes().to_list(None)
        result["mongo"] = {
            "live_collection": s.MONGODB_COLLECTION,
            "live_count": await col.count_documents({}, maxTimeMS=15000),
            "matching_collections": sorted(names),
            "indexes": [{"name": i.get("name"), "status": i.get("status"), "queryable": i.get("queryable"),
                         "definition_sha256": hashlib.sha256(json.dumps(i.get("latestDefinition"), sort_keys=True, default=str).encode()).hexdigest()}
                        for i in indexes],
        }
    except Exception as exc:
        result["mongo_error_type"] = type(exc).__name__
    finally:
        mongo.close()
    conn = None
    try:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", s.PGVECTOR_TABLE):
            raise ValueError("table name")
        conn = await asyncpg.connect(s.PGVECTOR_DSN, timeout=10, command_timeout=15)
        async with conn.transaction(readonly=True, isolation="repeatable_read"):
            tables = await conn.fetch("SELECT schemaname, tablename FROM pg_tables WHERE schemaname LIKE '%healthnews%' OR tablename LIKE '%healthnews%' OR tablename LIKE '%snapshot%' OR tablename = 'health_articles_chunks' ORDER BY 1,2")
            result["pg"] = {"live_table": s.PGVECTOR_TABLE,
                            "live_count": await conn.fetchval("SELECT count(*) FROM " + s.PGVECTOR_TABLE),
                            "matching_tables": [dict(row) for row in tables],
                            "readonly_transaction": True}
    except Exception as exc:
        result["pg_error_type"] = type(exc).__name__
    finally:
        if conn is not None:
            await conn.close()
    print(json.dumps(result, ensure_ascii=False, default=str))


asyncio.run(main())
