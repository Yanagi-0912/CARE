import asyncio
import json
import logging
import re
import time
from pathlib import Path

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from app.core.request_logging import log_stage
from app.core.user_language import normalize_user_language
from app.services.agent.prompt import build_date_context, build_system_prompt
from app.services.agent.utils.state import State
from app.services.media.tv_news_lookup import CHANNEL_ALIASES, CHANNEL_DOMAINS
from app.services.medical.department_matcher import (
    extract_department_intents,
    normalize_department_text,
)
from app.services.medical.facility_name_index import covers_known_facility_name
from app.services.medical.medical_facility_matcher import FACILITY_ALIASES
from app.services.medical.facility_type_matcher import (
    all_facility_type_terms,
    extract_facility_type_intent,
    normalize_facility_type_text,
)
from app.services.medical.symptom_classification.urgency import (
    NOT_URGENT,
    URGENCY_EMERGENCY,
    UrgencyVerdict,
)
from app.tools.claim_tools import CARD_CLAIM_NOT_FOUND, HEALTH_CARD_CLAIM_CALL_ID
from app.tools.registry import get_all_tools
from resources.flex_messages.medical_messages.emergency_condition_flex_message import (
    build_emergency_condition_flex,
)

logger = logging.getLogger(__name__)

# 本地「直接送 RAG」分類器的權重表，由 scripts/build_rag_route_dataset.py 產資料、
# scripts/build_guardrail_model.py 訓練。
RAG_ROUTE_MODEL_PATH = Path(__file__).resolve().parents[4] / "resources" / "rag_route_model.json"


def _already_ran_rag(messages) -> bool:
    return any(
        isinstance(m, ToolMessage) and m.name == "get_rag_answer" for m in messages
    )


def _already_ran_upload_document(messages) -> bool:
    return any(
        isinstance(m, ToolMessage) and m.name == "answer_from_uploaded_document"
        for m in messages
    )


_UPLOADED_DOCUMENT_RE = re.compile(
    r"上傳|剛傳|這份(?:PDF|檔|文件|報告)|我傳的|文件裡|PDF裡|報告裡",
    re.IGNORECASE,
)


def _is_uploaded_document_question(text: str) -> bool:
    """使用者追問已上傳文件內容；勿與一般衛教問題混淆。"""
    return bool(text and _UPLOADED_DOCUMENT_RE.search(text))


_LOCATION_TOOL_NAMES = frozenset(
    {
        "request_location_quick_reply",
        "find_nearby_hospitals",
        "find_nearby_facilities_by_department",
        "lookup_medical_facility",
    }
)


def _already_used_location_tools(messages) -> bool:
    return any(
        isinstance(m, ToolMessage) and m.name in _LOCATION_TOOL_NAMES
        for m in messages
    )


def _already_ran_symptom_suggestion(messages) -> bool:
    """
    本輪是否已產生科別建議卡。

    為什麼要擋 force_rag：科別建議卡已經是一份完整的回覆，再補一次 RAG 沒有
    加到任何東西，卻會多花十幾秒與一次模型呼叫。更嚴重的是 get_rag_answer 的
    「參考資料來源」後置處理會把來源段落接在最終回覆後面，而最終回覆是 Flex
    JSON 字串——被接了文字之後就不再是合法 JSON，LINE 端會退化成把整包 JSON
    當純文字送出。
    """
    return any(
        isinstance(m, ToolMessage) and m.name == "suggest_department_for_symptom"
        for m in messages
    )


def _latest_human_text(messages) -> str:
    for m in reversed(messages):
        if isinstance(m, HumanMessage):
            return m.content
    return ""


# LineLocationHandler 會把位置訊息轉成「這是我的目前位置：lat=..., lng=...」
# 這段文字才是 agent 實際看到的輸入。
_SHARED_LOCATION_RE = re.compile(
    r"lat\s*=\s*(-?\d+(?:\.\d+)?)\s*,\s*lng\s*=\s*(-?\d+(?:\.\d+)?)",
    re.IGNORECASE,
)


def _parse_shared_location(text: str) -> tuple[float, float] | None:
    """從使用者分享位置轉出的文字取出座標，取不到則回 None。"""
    if not text:
        return None
    match = _SHARED_LOCATION_RE.search(text)
    if not match:
        return None
    try:
        return float(match.group(1)), float(match.group(2))
    except ValueError:  # pragma: no cover - 正則已限制為數字
        return None


# 使用者提到科別的那一輪通常還沒有座標（「附近有腸胃科嗎」→ 請他分享位置），
# 等座標進來時，最新的一則 HumanMessage 已經是「這是我的目前位置：lat=…」，
# 科別資訊落在更早的訊息裡。只看最後一則會把科別整個弄丟，因此往回掃歷史。
_DEPARTMENT_INTENT_LOOKBACK = 4

# 「使用者有沒有指名某一科」與「那是哪一科」是兩個不同的問題，這裡只回答前者。
#
# 為什麼不能只靠 extract_department_intents：它解析不出來就回空的，於是
# 「指名了某一科，但別名表裡沒有」與「根本沒指名科別」在下游長得一模一樣。
# 前者應該讓 medical_service 用 LLM 兜底、真的兜不出來就誠實說看不懂；後者才該
# 做不分科搜尋。兩者混在一起的後果是科別被靜默丟掉——使用者說「大腸科」，卻拿到
# 一份包含牙科、婦產科的「附近醫療院所」清單，還以為系統聽懂了。
#
# 因此表查不到時改用字面判斷「這句話裡有沒有一個 X 科」，把原始說法原樣往下傳，
# 對應工作全部交給 medical_service 的兩層解析（別名表 → LLM 兜底）。這一層不做
# 任何醫療判斷，也不需要額外的 LLM 呼叫。
_DEPARTMENT_MENTION_RE = re.compile(
    # 排除「科技」「科學」「科系」「科班」「科目」「科普」「科別」「科室」——
    # 這些都是「科」後面還接字的一般詞彙，不是在指某一科。
    r"科(?![技學系班目普別室])"
)

# 找到「科」之後往回取字，遇到這些字就停。
#
# 為什麼是「停止字」而不是「剝掉開頭的語助詞」：後者要求語助詞剛好對齊比對起點，
# 一旦沒對齊就會整段吃進來——實測「請問哪裡有睡眠障礙科」會抽出「裡有睡眠障礙科」、
# 「他大學讀理科」會抽出「他大學讀理科」而逃過非科別詞的過濾。往回走到功能詞為止
# 不受對齊影響，上述兩句分別停在「有」與「讀」，得到「睡眠障礙科」與「理科」。
#
# 刻意不收「家」「學」「大」：家醫科、職業醫學科、大腸科都含這些字，收了會把
# 真正的科別名稱切斷。「哪家」「大學」分別由「哪」「讀／是」擋下。
_MENTION_STOP_CHARS = frozenset(
    "我你他她它們要想去看找有的了嗎呢吧啊嘛喔哦"
    "請問幫附近最周週圍鄰哪沒推薦介紹預約掛號讀"
    "是在這那很和跟與也都就才會能可及對於把被從到往向"
    "科"  # 連續兩個科（「婦產科內科」）不可黏成一個詞
)

# 往回取字的上限。最長的部定專科「兒童青少年精神科」是 8 個字，取到這個長度就夠；
# 再長多半是把整句話吃進來了。
_MENTION_MAX_CHARS = 8

# 字面上是「X科」但不是科別的常見詞。這裡只需要收「別名表查不到、又會被上面
# 正則撈到」的詞——真正的科別（內科、婦產科…）在別名表就命中了，根本走不到這。
_NOT_A_DEPARTMENT = frozenset(
    {
        "理科", "文科", "商科", "工科", "農科", "學科", "術科", "本科",
        "專科", "全科", "分科", "選科", "轉科", "這科", "那科", "哪科",
    }
)


def _looks_like_department_mention(text: str) -> str | None:
    """
    這句話裡有沒有指名某一科？有的話回傳使用者的原始說法，沒有回 None。

    刻意不判斷那是不是真的存在的科別——那是 medical_service 的工作。
    """
    cleaned = normalize_department_text(text)
    if not cleaned:
        return None

    for match in _DEPARTMENT_MENTION_RE.finditer(cleaned):
        end = match.start()  # 「科」本身的位置
        start = end
        while start > 0 and end - start < _MENTION_MAX_CHARS:
            char = cleaned[start - 1]
            if char in _MENTION_STOP_CHARS or not ("一" <= char <= "鿿"):
                break
            start -= 1

        candidate = cleaned[start : end + 1]
        # 只剩「科」一個字代表前面全是功能詞，不是在指名科別。
        if len(candidate) < 2 or candidate in _NOT_A_DEPARTMENT:
            continue
        return candidate

    return None


def _extract_department_from_history(messages) -> list[str]:
    """
    由新到舊掃描使用者訊息，找出最近一次提到的科別（使用者的原始說法）。

    同一則訊息列舉了多科（保底卡按鈕的「搜尋附近的家醫科、內科、不分科」）就全部
    帶上；沒提到科別時回傳空清單。只掃最近幾則，避免把很久以前、已經聊完的科別
    誤套到這次搜尋上。
    """
    scanned = 0
    for message in reversed(messages):
        if not isinstance(message, HumanMessage):
            continue

        text = message.content if isinstance(message.content, str) else ""
        # 位置訊息是系統轉出來的文字，不是使用者在描述需求，跳過但不計入回溯長度。
        if _parse_shared_location(text) is not None:
            continue

        scanned += 1
        if scanned > _DEPARTMENT_INTENT_LOOKBACK:
            return []

        matches = extract_department_intents(text)
        if matches:
            return [match.requested for match in matches]

        # 別名表查不到，但字面上確實指名了某一科 → 原樣往下傳，讓 service 層去對應。
        mention = _looks_like_department_mention(text)
        if mention is not None:
            logger.info(
                "[Agent] 別名表未收錄但字面指名了科別，交由 service 層解析：%r",
                mention,
            )
            return [mention]

    return []


# 「現在有開的」是使用者主動加上的限定，不能從「附近有診所嗎」推論出來 ——
# 午休時段只有 11.5% 的院所營業，預設篩選會刪掉大量其實稍後就開診的院所。
# 講到半夜／深夜／凌晨，或「現在要去看醫生」，就是現在要去，一樣算。
# 「有營業的」「還有開嗎」原本判不出來 —— 使用者明講了，拿到的還是一排沒開的。
_OPEN_NOW_RE = re.compile(
    r"現在(?:有|還)?(?:開|營業|看診|門診)|還在(?:看診|營業|開)|"
    r"有開的|開著的|營業中|正在營業|還沒關|來得及|"
    r"有(?:在)?營業(?!時間)|還有(?:在)?開|"
    r"半夜|深夜|凌晨|"
    r"現在(?:就)?(?:要|想)(?:去)?(?:看醫生|看病|看診|就醫)|"
    r"open\s*now|still\s*open|open\s*right\s*now",
    re.IGNORECASE,
)


def _is_open_now_intent(text: str) -> bool:
    """使用者是否明確要求只看現在營業中的院所。"""
    if not text or _is_media_extracted_content(text):
        return False
    return bool(_OPEN_NOW_RE.search(text))


def _wants_open_now_from_history(messages) -> bool:
    """
    回溯使用者訊息，判斷是否曾要求「現在有開的」。

    與科別意圖同理：提出需求的那一輪通常還沒有座標，等座標進來時最新訊息已是
    系統轉出的座標文字。
    """
    scanned = 0
    for message in reversed(messages):
        if not isinstance(message, HumanMessage):
            continue

        text = message.content if isinstance(message.content, str) else ""
        if _parse_shared_location(text) is not None:
            continue

        scanned += 1
        if scanned > _DEPARTMENT_INTENT_LOOKBACK:
            return False

        if _is_open_now_intent(text):
            return True

    return False


# 真正有歧義的只有裸詞「醫院」與「門診」兩個：
#   -「醫院」在口語中常泛指「醫療院所」——「我要去醫院」「附近有醫院嗎」多半只是
#     想看病，不代表使用者在意規模／是否要住院。照字面套上醫院類過濾會把
#     18,935 家診所全數排除，反而讓結果更差。
#   -「門診」在別名表裡對應到「診所」，但醫院本身也有門診部，「我要看門診」
#     和裸詞「醫院」一樣是泛稱看病，不足以推論使用者要找診所而非醫院。
# 其餘所有說法（綜合醫院、專科診所、牙醫診所、大醫院、藥師自營…）都已經明確
# 指出規模／型態，沒有這種泛稱問題。
#
# 因此白名單用「facility_type_matcher 認得的全部詞彙 **扣掉** 這兩個歧義詞」
# 表述，而不是正面列舉幾個俗稱。先前正面列舉 8 個俗稱的寫法有個靜默失效的
# 破口：extract_facility_type_intent() 採最長優先掃描，會回傳資料庫的**正式
# type 值**（「附近有綜合醫院嗎」→ requested="綜合醫院"），這些值不在那份手寫
# 清單裡，於是整句被判定為「沒有類型意圖」而退回不帶 facility_type 的搜尋 ——
# 也就是退回本 change 原本要修的那個 bug。改成扣除式之後，別名表或資料庫新增
# 類型值時這裡不必跟著改，兩份清單也就不可能失去同步。
_AMBIGUOUS_FACILITY_TYPE_TERMS = frozenset({"醫院", "門診"})
_UNAMBIGUOUS_FACILITY_TYPE_TERMS = (
    all_facility_type_terms() - _AMBIGUOUS_FACILITY_TYPE_TERMS
)

# 判斷「這個類型詞是專名還是泛稱」的做法演進過三輪字元規則，全部失敗：
#   1. 連接詞白名單（要求整段前綴被消耗殆盡）→ 擋掉「評價不錯的診所」
#   2. 緊鄰語法標記 → 「皇家」「全家」「我家」的「家」被當成量詞標記
#   3. 標記分三層 → 35 家誤判降到 2 家，代價是「好的診所」「多家診所」失效
# 共同的根因是拿字元形態去猜一個事實問題。改用 facility_name_index 直接查
# 資料庫裡的院所名稱，詳見 _looks_like_named_facility。
def _looks_like_named_facility(cleaned: str, start: int, end: int) -> bool:
    """
    `cleaned[start:end]` 這個類型詞，是某家院所專名的最後幾個字嗎？

    先前用三輪字元規則猜過這件事（連接詞白名單 → 緊鄰語法標記 → 標記分三層），
    每輪都在新方向開破口：第一輪擋掉「評價不錯的診所」，第二輪把「皇家診所」
    當成泛稱，第三輪修好 35 家誤判中的 33 家、代價是「好的診所」「多家診所」失效。
    根本問題是拿字元形態去猜一個**事實**——這串字是不是某家院所的名字。
    資料庫裡有答案，不需要猜。

    改成兩道事實查核，任一成立即視為專名：

    1. **登記名稱**：`facility_name_index` 收了全部 19,528 筆院所名稱。
       「皇家診所」「全家診所」「我家診所」「和睦家診所」「美的診所」
       「一家牙醫診所」都確實登記在案；而「好的診所」「多家診所」
       「評價不錯的診所」等泛稱片語沒有一個與院所名稱碰撞。
    2. **口語簡稱**：資料庫存的是正式名稱，使用者說的常是簡稱——
       「台大醫院」在庫裡叫「國立臺灣大學醫學院附設醫院」，查不到。
       這類由既有的 `FACILITY_ALIASES`（臺大／成大／馬偕／榮總／長庚…）補上。

    類型詞位於句首（「診所在哪」）時前面沒有文字可疑，不可能是專名尾巴。
    索引未載入時第 1 道恆為 False，只剩別名表把關——方向是漏判而非誤判，
    退回的是未套類型過濾的現況行為。
    """
    if start == 0:
        return False

    if covers_known_facility_name(cleaned, start, end):
        return True

    return _has_facility_alias_at(cleaned, start)


def _has_facility_alias_at(cleaned: str, start: int) -> bool:
    """
    位置 start 之前是否緊接著一個已知的院所簡稱。

    要處理重疊：「臺大醫院」比對到的類型詞是「大醫院」（start=1），而簡稱
    「臺大」佔的是 [0, 2)，兩者共用「大」這個字。所以判定條件不是
    「前綴以簡稱結尾」，而是「簡稱的結束位置抵達或越過 start」——
    緊鄰（臺大｜醫院）與重疊（臺｜大醫院）兩種情形都涵蓋。
    """
    for alias in FACILITY_ALIASES:
        alias_start = cleaned.find(alias)
        while alias_start != -1:
            alias_end = alias_start + len(alias)
            if alias_start < start <= alias_end:
                return True
            alias_start = cleaned.find(alias, alias_start + 1)
    return False


def _facility_type_intent(text: str) -> str | None:
    """
    嚴格版的院所類型意圖判定：只有出現明確語彙才回傳使用者的原始說法。

    不能直接回傳 extract_facility_type_intent() 的 match.requested——
    見上方 _AMBIGUOUS_FACILITY_TYPE_TERMS 的說明，裸詞「醫院」會被
    resolve 成 requested="醫院"，必須擋下來。

    白名單詞彙有可能是具名院所全名的一部分（「台大醫院」內含「大醫院」，
    「皇家診所」「康是美藥局」內含「診所」「藥局」），因此比對到之後還要用
    _looks_like_named_facility() 查核那是不是某家院所的名字；
    比對詞若在文字中出現多次，只要有一次不是專名的一部分就採信，
    全部都是專名才回 None。
    """
    match = extract_facility_type_intent(text)
    if match is None or match.requested not in _UNAMBIGUOUS_FACILITY_TYPE_TERMS:
        return None

    cleaned = normalize_facility_type_text(text)
    term = match.requested
    index = cleaned.find(term)
    while index != -1:
        if not _looks_like_named_facility(cleaned, index, index + len(term)):
            return term
        index = cleaned.find(term, index + 1)

    return None


def _extract_facility_type_from_history(messages) -> str | None:
    """
    由新到舊掃描使用者訊息，找出最近一次明確表達的院所類型（原始說法）。

    沿用 _extract_department_from_history 的回溯上限與跳過座標訊息的邏輯：
    使用者提出類型需求的那一輪通常還沒有座標，等座標進來時最新的 HumanMessage
    已是系統轉出的座標文字，類型資訊落在更早的訊息裡。
    """
    scanned = 0
    for message in reversed(messages):
        if not isinstance(message, HumanMessage):
            continue

        text = message.content if isinstance(message.content, str) else ""
        if _parse_shared_location(text) is not None:
            continue

        scanned += 1
        if scanned > _DEPARTMENT_INTENT_LOOKBACK:
            return None

        facility_type = _facility_type_intent(text)
        if facility_type is not None:
            return facility_type

    return None


_FACILITY_SEARCH_RE = re.compile(
    r"醫院|診所|藥局|看醫生|就醫|急診|附近院所|找醫院|找診所|看診|"
    r"hospital|clinic|pharmacy",
    re.IGNORECASE,
)
_NAMED_LOOKUP_RE = re.compile(r"在哪|地址|電話|怎麼去")
_FACILITY_TERM_RE = re.compile(
    r"醫院|診所|藥局|hospital|clinic|pharmacy", re.IGNORECASE
)
# LineMediaHandler 會把 OCR／抽字結果包成此前綴再送進 agent。
# 文件全文常含「就醫／診所」等衛教用語，不能當成使用者要找附近院所。
# 語音不在此列：逐字稿不包前綴（見 media_handler），是使用者親口的提問，照一般訊息處理。
_MEDIA_EXTRACTED_CONTENT_RE = re.compile(
    r"^以下為使用者傳送的(?:image|video|file)媒體內容："
)


def _is_media_extracted_content(text: str) -> bool:
    return bool(text and _MEDIA_EXTRACTED_CONTENT_RE.match(text))


# 長輩拍電視新聞畫面。n8n 的影像節點認出 tv_news 時，`text` 一律由台別與標題
# 重建成這個格式（CARE-n8n `mutimedia process.json` 的 Code 節點；受訪者字幕與
# 跑馬燈刻意不下送，那是 scripts/tv_news_eval.py 量到的主要失效）：
#
#     以下為使用者傳送的image媒體內容：
#     【電視新聞畫面】
#     電視台：TVBS
#     新聞標題：維他命添色素‧影響智力
#     （標題可能不完整或有字看不清楚）
_TV_NEWS_MARKER = "【電視新聞畫面】"
_TV_NEWS_HEADLINE_RE = re.compile(r"^新聞標題：(.+)$", re.MULTILINE)
_TV_NEWS_CHANNEL_RE = re.compile(r"^電視台：(.+)$", re.MULTILINE)


def _tv_news_claim(text: str) -> str | None:
    """電視新聞畫面上的主標題，也就是要拿去查核的那句話。

    沒抓到標題的畫面回 None：n8n 那端會改寫「畫面上沒有看到這則新聞的標題」，
    拿台別去查核沒有意義，那種畫面就照一般媒體內容描述給長輩聽。
    """
    if not _is_media_extracted_content(text) or _TV_NEWS_MARKER not in text:
        return None
    match = _TV_NEWS_HEADLINE_RE.search(text)
    if not match:
        return None
    return match.group(1).strip() or None


def _tv_news_channel_answer(text: str) -> str:
    """使用者回答「這則新聞是哪一台」時說的台名；不是在回答台別就回空字串。

    快速回覆按鈕送出的是「這則新聞是民視」，但長輩也可能自己打「民視」或
    「民視新聞」，所以認的是台名與別名，不是整句比對。限制長度是為了不要把
    「民視報導說吃芒果會怎樣」這種有實質內容的問句誤判成在回答台別——那句
    該照常走查核。
    """
    stripped = (text or "").strip()
    if not stripped or len(stripped) > 12:
        return ""
    for channel, aliases in CHANNEL_ALIASES.items():
        if channel not in CHANNEL_DOMAINS:
            continue
        if any(alias.lower() in stripped.lower() for alias in aliases):
            return channel
    return ""


def _previous_tv_news_headline(messages) -> str:
    """對話裡最近一張電視新聞畫面的標題。找不到回空字串。"""
    for message in reversed(messages):
        if not isinstance(message, HumanMessage):
            continue
        claim = _tv_news_claim(str(message.content or ""))
        if claim:
            return claim
    return ""


def _tv_news_channel(text: str) -> str:
    """畫面上的電視台。n8n 認不出台別時整行不會出現，所以沒有「不確定」這個值。"""
    if not _is_media_extracted_content(text):
        return ""
    match = _TV_NEWS_CHANNEL_RE.search(text)
    return match.group(1).strip() if match else ""


# 「附近有腸胃科嗎」不含醫院／診所等字眼，_FACILITY_SEARCH_RE 抓不到，
# 但它確實是在找附近院所。改以「鄰近詞 + 科別」的組合另行判定。
# 之所以要求同時出現鄰近詞，是為了把「我牙齒痛」這類純症狀敘述排除在外 ——
# 那種情況使用者多半想問衛教，不該直接跳出要位置的按鈕。
_PROXIMITY_RE = re.compile(
    r"附近|最近|周邊|週邊|周圍|鄰近|哪裡有|哪裡可以|哪一家|哪家|推薦|"
    r"nearby|near\s*me|closest|around|"
    r"terdekat|di\s*sekitar|"
    r"gần\s*đây|gần\s*tôi|"
    r"ใกล้เคียง|ใกล้ฉัน|"
    r"近く|最寄り",
    re.IGNORECASE,
)


def _is_nearby_department_intent(text: str) -> bool:
    """使用者在找「附近的某一科」，例如「附近有腸胃科嗎」。"""
    if not text or _is_media_extracted_content(text):
        return False
    if _NAMED_LOOKUP_RE.search(text):
        return False
    if not _PROXIMITY_RE.search(text):
        return False
    return bool(extract_department_intents(text))


# 「我要看大腸科」既沒有鄰近詞，也沒有醫院／診所字眼，上面兩道判定都抓不到，
# 於是整句掉進強制 RAG —— 使用者想找院所，收到的卻是一段「大腸直腸科醫師在看什麼」
# 的衛教說明。指名科別 + 就診動詞已經足夠明確表達要看這一科，不必再等鄰近詞。
#
# 判定要求動詞緊接在科別前面、科別後面只剩收尾的詞，兩道都是為了不把衛教問句
# 誤判成找院所（那會用一顆要位置的按鈕蓋掉使用者真正想問的問題）：
#   - 只看「句中有沒有就診動詞」→「腸胃科是看什麼的」會因為那個「看」中招。
#   - 只看「動詞是否緊接科別」→「上次看腸胃科醫師說要多喝水，這樣對嗎」這種
#     轉述句仍會中招，因此科別之後只允許「的醫生／醫師／門診」與語助詞收尾。
_DEPARTMENT_VISIT_ACTION_RE = re.compile(r"(?:看|掛號|掛|預約|轉|找)(?:個|一下)?$")
_DEPARTMENT_VISIT_TAIL_RE = re.compile(r"^(?:的?(?:醫生|醫師|門診))?[嗎呢吧啊喔哦耶]*$")


def _is_department_visit_intent(text: str) -> bool:
    """使用者指名科別並表明要就診，例如「我要看大腸科」「幫我掛腸胃科」。"""
    if not text or _is_media_extracted_content(text):
        return False
    if _NAMED_LOOKUP_RE.search(text):
        return False

    # 別名表查不到時沿用 _looks_like_department_mention 的字面判定，
    # 「我要看腹腔鏡科」這類未收錄的說法才不會因為查表落空就掉回 RAG。
    matches = extract_department_intents(text)
    term = matches[0].requested if matches else _looks_like_department_mention(text)
    if not term:
        return False

    cleaned = normalize_department_text(text)
    index = cleaned.find(term)
    while index != -1:
        before = cleaned[:index]
        after = cleaned[index + len(term) :]
        if _DEPARTMENT_VISIT_ACTION_RE.search(before):
            if _DEPARTMENT_VISIT_TAIL_RE.match(after):
                return True
        index = cleaned.find(term, index + 1)

    return False


def _is_nearby_facility_intent(text: str) -> bool:
    if not text or _NAMED_LOOKUP_RE.search(text):
        return False
    if _is_media_extracted_content(text):
        return False
    if _FACILITY_SEARCH_RE.search(text):
        return True
    return _is_nearby_department_intent(text) or _is_department_visit_intent(text)


def _is_named_facility_lookup(text: str) -> bool:
    if not text or _is_media_extracted_content(text):
        return False
    return bool(_NAMED_LOOKUP_RE.search(text) and _FACILITY_TERM_RE.search(text))


_OFFICIAL_SITE_ACTION_RE = re.compile(
    r"打開|開啟|進入|入口|連結|怎麼開|如何開",
    re.IGNORECASE,
)
_OFFICIAL_SITE_TERM_RE = re.compile(
    r"官網|官方網站|官方入口|網站連結|(?<![a-z])liff(?![a-z])",
    re.IGNORECASE,
)
_OFFICIAL_SITE_DIRECT_RE = re.compile(
    r"^(?:打開官網|打開網站|官網連結|網站連結|官方網站|打開官方網站|"
    r"打開\s*liff|liff\s*入口|liff\s*怎麼開|怎麼開\s*liff|"
    r"官網入口|官方入口)(?:[？?！!。．\s]*)$",
    re.IGNORECASE,
)


def _is_official_site_intent(text: str) -> bool:
    """使用者要開啟官網／LIFF 入口；偏短意圖，避免「官網疫苗資訊」等衛教句誤觸。"""
    if not text or _is_media_extracted_content(text):
        return False
    stripped = text.strip()
    if _OFFICIAL_SITE_DIRECT_RE.match(stripped):
        return True
    if _OFFICIAL_SITE_ACTION_RE.search(stripped) and _OFFICIAL_SITE_TERM_RE.search(
        stripped
    ):
        return True
    return False


def _already_ran_official_site(messages) -> bool:
    return any(
        isinstance(m, ToolMessage) and m.name == "open_official_site" for m in messages
    )


_CHRONIC_CODE_LABELS = {
    "hypertension": "高血壓",
    "diabetes": "糖尿病",
    "hyperlipidemia": "高血脂",
    "heartDisease": "心臟病",
    "kidneyDisease": "腎臟病",
    "asthma": "氣喘",
    "copd": "慢性阻塞性肺病",
    "cancer": "癌症",
}

# 舊資料存過中文，查不到就原樣輸出，與上面同一個規則
_GENDER_LABELS = {"male": "男", "female": "女", "unknown": "未提供"}


def _format_chronic(user_profile: dict) -> str:
    """固定選項的 code 還原成中文，接上使用者自行輸入的病名（後者原文照用）。"""
    names = [
        _CHRONIC_CODE_LABELS.get(code, code)
        for code in user_profile.get("chronic_diseases") or []
    ]
    names += list(user_profile.get("chronic_custom") or [])
    return "、".join(names) or "無"


def format_user_profile_prompt(user_profile: dict | None) -> str:
    if not user_profile:
        return ""

    name = user_profile.get("name") or "未提供"
    gender_code = user_profile.get("gender") or "unknown"
    gender = _GENDER_LABELS.get(gender_code, gender_code)
    age = user_profile.get("age")
    age_str = f"{age} 歲" if age is not None and age > 0 else "未提供"
    height = user_profile.get("height")
    height_str = f"{height} cm" if height and height > 0 else "未提供"
    weight = user_profile.get("weight")
    weight_str = f"{weight} kg" if weight and weight > 0 else "未提供"
    chronic = _format_chronic(user_profile)
    major = user_profile.get("major_illness_history") or "無"
    surgery = user_profile.get("surgery_history") or "無"

    return (
        f"\n\n【對話使用者的個人健康與病史檔案】\n"
        f"- 姓名/稱呼：{name}\n"
        f"- 性別：{gender}\n"
        f"- 年齡：{age_str}\n"
        f"- 身高：{height_str}\n"
        f"- 體重：{weight_str}\n"
        f"- 慢性病史：{chronic}\n"
        f"- 重大疾病史：{major}\n"
        f"- 手術史：{surgery}\n"
        f"請在回答使用者問題時，考慮其個人的健康數據、病史與特殊注意事項，提供適切且具關懷溫度的客製化建議。"
    )


def _consume_task_exception(task: "asyncio.Task") -> None:
    if not task.cancelled():
        task.exception()


def _abandon_task(task: "asyncio.Task | None") -> None:
    """收掉不再需要的任務。冪等，可安全重複呼叫。

    與 answer_service._abandon_task 相同：已完成且帶例外時要主動取出例外，
    否則 asyncio 會噴 "Task exception was never retrieved"。
    """
    if task is None or task.cancelled():
        return
    if not task.done():
        task.cancel()
        return
    task.exception()


def _can_send_original_text_to_rag(state: State, tool_names: list[str], user_text: str) -> bool:
    """不經模型、直接把使用者原句送 `get_rag_answer`，在決定性規則上是否站得住。

    強制轉 RAG（模型沒呼叫任何工具）與本地捷徑（根本不問模型）共用這組條件。
    兩條路送出的是同一種呼叫，排除的情況就必須一致——各寫一份，遲早有一邊
    補了新規則、另一邊沒補。
    """
    messages = state["messages"]
    return bool(
        state.get("allow_rag")
        and "get_rag_answer" in tool_names
        and not _already_ran_rag(messages)
        and not _already_used_location_tools(messages)
        and not _already_ran_symptom_suggestion(messages)
        and not _is_nearby_facility_intent(user_text)
        and not _is_named_facility_lookup(user_text)
        and not _is_official_site_intent(user_text)
        and not _is_media_extracted_content(user_text)
        and not _is_uploaded_document_question(user_text)
    )


def _tv_news_channel_followup(
    state: State, tool_names: list[str], user_text: str
) -> AIMessage | None:
    """上一張電視新聞畫面認不出台別、這一句在回答是哪一台 → 這時才查核。

    認不出台別時我們先問、不查（見 `_tv_news_claim_call`），所以這一步是那則
    新聞的第一次查核，帶著台別一起做，判定與原始報導連結一次給完。

    為什麼要決定性地送：這句話只有兩個字（「民視」），交給模型判斷等於讓它猜
    上下文，而它猜錯的方式是把台名當成一個健康問題送去查知識庫。這裡的條件
    夠窄——上一輪必須真的有電視新聞畫面——所以可以直接接。
    """
    if "verify_tv_news" not in tool_names:
        return None
    if any(isinstance(m, ToolMessage) for m in state["messages"]):
        return None
    channel = _tv_news_channel_answer(user_text)
    if not channel:
        return None
    headline = _previous_tv_news_headline(state["messages"])
    if not headline:
        return None
    log_stage(logger, "tv_news_channel_answer", channel=channel)
    return AIMessage(
        content="",
        tool_calls=[
            {
                "name": "verify_tv_news",
                "args": {"headline": headline, "channel": channel},
                "id": "tv_news_followup_1",
                "type": "tool_call",
            }
        ],
    )


def _tv_news_claim_call(
    state: State, tool_names: list[str], user_text: str
) -> AIMessage | None:
    """長輩拍了電視新聞畫面時，直接拿標題去查核，不問模型。

    為什麼要決定性地送：prompt 規則 (e) 本來禁止媒體內容查知識庫，因為文件與
    圖片抽出的文字多半是「請讀給我聽」而不是提問。但電視新聞的標題正好相反，
    它是一句待查證的主張——2026-09-17 長輩拍了「維他命添色素‧影響智力」，
    CARE 只能照畫面複述，給不出任何出處，而那正是最需要查核的一種訊息。

    先 `verify_claim` 而不是 `get_rag_answer`：標題是「某某會怎樣」的主張，
    查核中心收錄過就有判定與原始查核報告連結；沒收錄時判定卡也會附上知識庫
    裡的相關衛教（見 claim_verification/service.py），兩種情況都給得出來源。
    查核服務沒開時退而求其次送知識庫，至少答案帶參考資料。

    **不放行非健康的新聞**：這裡要求 `allow_rag`，而 guardrail 不放行的畫面
    （颱風、選舉）拿不到任何知識庫工具，維持照畫面描述的舊行為。
    """
    if not state.get("allow_rag"):
        return None
    # 工具回來之後那一步是在組回覆，不是在選工具（同 `_local_rag_shortcut`）。
    if any(isinstance(m, ToolMessage) for m in state["messages"]):
        return None
    claim = _tv_news_claim(user_text)
    if not claim:
        return None
    # verify_tv_news 的判定卡會多一顆「看新聞原文」：長輩拍畫面就是為了那則
    # 新聞，查核報告與衛教文章都回答不了「我看到的那則在哪裡」。
    channel = _tv_news_channel(user_text)
    # 認不出台別就先問、先不查（2026-09-19 James 拍板）：問到台別才查得準，
    # 也才找得到原始報導，一次給完整的答案。代價是長輩不回答就不會有判定。
    if not channel and "ask_tv_news_channel" in tool_names:
        log_stage(logger, "tv_news_claim", tool="ask_tv_news_channel")
        return AIMessage(
            content="",
            tool_calls=[
                {
                    "name": "ask_tv_news_channel",
                    "args": {"headline": claim},
                    "id": "tv_news_ask_1",
                    "type": "tool_call",
                }
            ],
        )
    if "verify_tv_news" in tool_names:
        name, call_id = "verify_tv_news", "tv_news_verify_1"
        args = {"headline": claim, "channel": channel}
    elif "verify_claim" in tool_names:
        name, call_id = "verify_claim", "tv_news_claim_1"
        args = {"query": claim}
    elif "get_rag_answer" in tool_names:
        name, call_id = "get_rag_answer", "tv_news_rag_1"
        args = {"query": claim}
    else:
        return None
    log_stage(logger, "tv_news_claim", tool=name)
    return AIMessage(
        content="",
        tool_calls=[
            {"name": name, "args": args, "id": call_id, "type": "tool_call"}
        ],
    )


# 謠言長輩圖、衛教海報這類「一張圖講一件健康的事」的圖卡。n8n 的影像節點抽得出
# 那句主張時，在 `text` 最前面加上這兩行（CARE-n8n `mutimedia process.json`）：
#
#     以下為使用者傳送的image媒體內容：
#     【健康圖卡】
#     圖卡主張：甜柿和螃蟹一起吃會中毒
#
#     （圖上的原文）
#
# n8n 不判斷真假——同一句「柿子配螃蟹」可能是謠言圖，也可能是闢謠的衛教圖。
_HEALTH_CARD_MARKER = "【健康圖卡】"
_HEALTH_CARD_CLAIM_RE = re.compile(r"^圖卡主張：(.+)$", re.MULTILINE)


def _health_card_claim(text: str) -> str | None:
    if not _is_media_extracted_content(text) or _HEALTH_CARD_MARKER not in text:
        return None
    match = _HEALTH_CARD_CLAIM_RE.search(text)
    if not match:
        return None
    return match.group(1).strip() or None


def _health_card_claim_call(
    state: State, tool_names: list[str], user_text: str
) -> AIMessage | None:
    """長輩傳了健康圖卡時，直接拿圖上的主張去查，不問模型。

    2026-09-21 使用者傳了「甜柿＆螃蟹一起吃會中毒？」的圖，模型照規則 (e) 自己
    回答，沒有出處；一分鐘後打字問同一句，查核資料庫命中食藥署的闢謠、回了
    判定卡。圖卡和電視新聞標題一樣是一句待查證的話（見 `_tv_news_claim_call`）。

    先查核資料庫、沒收錄再送知識庫（見 `_health_card_rag_followup`），所以
    謠言與正確的衛教圖都拿得到有出處的答案，不必先分辨是哪一種。
    """
    if not state.get("allow_rag"):
        return None
    if any(isinstance(m, ToolMessage) for m in state["messages"]):
        return None
    claim = _health_card_claim(user_text)
    if not claim:
        return None
    if "verify_claim" in tool_names:
        name, call_id = "verify_claim", HEALTH_CARD_CLAIM_CALL_ID
        args = {"query": claim}
    elif "get_rag_answer" in tool_names:
        name, call_id = "get_rag_answer", "health_card_rag_1"
        args = {"query": claim}
    else:
        return None
    log_stage(logger, "health_card_claim", tool=name)
    return AIMessage(
        content="",
        tool_calls=[{"name": name, "args": args, "id": call_id, "type": "tool_call"}],
    )


def _health_card_rag_followup(
    state: State, tool_names: list[str], user_text: str
) -> AIMessage | None:
    """圖卡主張查核資料庫沒收錄 → 同一句送知識庫，回一般的衛教答案。

    不回「證據不足」判定卡：衛教海報多半是對的，只是查核中心沒查過，標成證據
    不足會讓長輩以為那張海報有問題。
    """
    messages = state["messages"]
    last = messages[-1] if messages else None
    if not (
        isinstance(last, ToolMessage)
        and last.tool_call_id == HEALTH_CARD_CLAIM_CALL_ID
        and last.content == CARD_CLAIM_NOT_FOUND
    ):
        return None
    claim = _health_card_claim(user_text)
    if not claim or "get_rag_answer" not in tool_names or _already_ran_rag(messages):
        return None
    log_stage(logger, "health_card_claim", tool="get_rag_answer", reason="not_in_claims")
    return AIMessage(
        content="",
        tool_calls=[
            {
                "name": "get_rag_answer",
                "args": {"query": claim},
                "id": "health_card_rag_1",
                "type": "tool_call",
            }
        ],
    )


def _original_text_rag_call(user_text: str, call_id: str) -> AIMessage:
    return AIMessage(
        content="",
        tool_calls=[
            {
                "name": "get_rag_answer",
                # TODO(對話記憶)：這裡把使用者這句話原樣當查詢，RAG 那頭
                # 也只看這一句。追問（「那第二種呢」）沒有前文就查不到、
                # 個人病史也進不了生成。要把對話歷史與個人檔案帶進 RAG
                # 生成是獨立功能，規劃見 CARE_對話記憶功能規劃.md。
                "args": {"query": user_text},
                "id": call_id,
                "type": "tool_call",
            }
        ],
    )


class AgentNodes:
    def __init__(self, llm, guardrail_service, urgency_classifier=None, rag_router=None):
        self._llm = llm
        self._guardrail_service = guardrail_service
        # 未注入時等同永遠不緊急。讓既有的測試與其他進入點不必全部改簽名，
        # 但正式路徑一定要注入——沒注入就等於沒有安全檢查。
        self._urgency_classifier = urgency_classifier
        # 本地「直接送 RAG」分類器（見 `_local_rag_shortcut`）。未注入＝每一則
        # 都照舊問模型，行為與導入前相同。
        self._rag_router = rag_router

    def _local_rag_shortcut(self, state: State, tool_names: list[str], user_text: str) -> bool:
        """本地模型有把握這句最後會走 RAG 時，跳過 agent 選工具的那次呼叫。

        那次呼叫在正式環境（2026-09-07～17，144 次）中位數 3.2 秒、p90 7.2 秒，
        而 guardrail 放行後的健康問題大多數最後都走 `get_rag_answer`。本地模型
        的標籤是拿正式的 `agent_node` 逐句標出來的（scripts/build_rag_route_dataset.py），
        學的是「agent 會怎麼選」，不是另訂一套規則。

        **只用 `high`，不用 `low`。** 本地說「不是 RAG」時仍要模型決定是哪個
        工具、參數是什麼，那是分類器做不到的，所以低分一律照舊問模型。

        **只在這一輪還沒跑過任何工具時判斷。** 工具回來之後的那一步是在組回覆，
        不是在選工具。

        門檻（`high`）以「交叉驗證上，該交給其他工具的訊息誤送率 ≤ 1%」選定。
        holdout 實測（2026-09-17，scripts/rag_route_eval.py）：agent 會走 RAG 的
        健康問題有 53.7% 走捷徑（中文 41.2%，外語 49.5%～63.9%）；agent 選了別的
        工具的 38 則誤送 2 則，生成的困難負例（掛哪科、查吃藥、查證、追問…）
        567 則誤送 5 則，多半是追問句。

        與模型路徑的差別：模型會把問句改寫成關鍵字串再送 RAG（6,342 則裡 6,065
        則），捷徑送原句——與強制轉 RAG 相同。golden 題庫 31 題知識庫題的檢索：
        原句命中 30、MRR 0.723；模型的關鍵字命中 29、MRR 0.755，看不出差別。
        題庫都是短問句，長句口語上的差別沒有量到。
        """
        router = self._rag_router
        if router is None:
            return False
        messages = state["messages"]
        if any(isinstance(m, ToolMessage) for m in messages):
            return False
        if _parse_shared_location(user_text) is not None:
            return False
        if not _can_send_original_text_to_rag(state, tool_names, user_text):
            return False
        try:
            probability = router.probability(user_text)
            recognized = router.recognizes(user_text)
        except Exception:
            # 捷徑壞掉只是變慢，不該讓這則訊息失敗。
            logger.exception("本地 RAG 分流推論失敗，照舊交給 agent")
            return False
        # 認得的片段太少時機率沒有意義（見 guardrail.local.MIN_KNOWN_SHARE）。
        shortcut = recognized and probability >= router.high
        log_stage(
            logger,
            "rag_route_local",
            p=round(probability, 3),
            outcome="shortcut" if shortcut else "agent",
            reason=None if recognized else "unrecognized",
        )
        return shortcut

    def _resolve_user_language(self, user_profile: dict | None) -> str:
        if not user_profile:
            return normalize_user_language(None)
        settings = user_profile.get("settings") or {}
        return normalize_user_language(settings.get("language"))

    async def guardrail_node(self, state: State) -> dict:
        """
        進 agent 之前的兩項判斷：是否允許 RAG、以及狀況是否緊急。

        兩者併發執行：急迫度判斷擋在所有回覆前面，序列化等於把它的延遲直接
        加到每一則訊息上。兩個判斷彼此獨立，沒有順序需求。

        但等待的方式不是 gather：先等急迫度，判定緊急就直接短路，不等 guardrail。
        緊急卡不進 agent、不跑 RAG，guardrail 的結果對它完全用不到；以前用
        gather 等兩邊都回來，Gemini 一慢，「我阿公昏迷」的紅卡就被一個沒人要的
        判斷拖住（guardrail 直到 2026-09-16 才有逾時，急迫度早就有 4 秒）。
        不緊急時仍要等 guardrail，總時間與 gather 相同——兩個任務一開始就同時起跑。

        急迫度為什麼在這裡而不是做成 tool：
            做成 tool 就代表「agent 可以選擇不呼叫」，而前一版失敗的原因正是
            agent 把「我阿公昏迷」判給了 RAG、從未呼叫到帶有安全檢查的工具。
            安全檢查不能是 agent 的選項，所以它排在 agent 之前。
        """
        user_input = state["messages"][-1].content
        language = self._resolve_user_language(state.get("user_profile"))
        t0 = time.perf_counter()

        # 回答我們問的「這則新聞是哪一台」時直接放行，不問 guardrail。
        #
        # 2026-09-19 線上：使用者點了快速回覆的「這則新聞是三立」（7 個字），
        # guardrail 判定不是健康問題（allow_rag=False），於是查核工具整組沒被
        # 提供，電視新聞的後續路由接不上，模型自己寫了一段沒有出處的說明。
        #
        # 這句話本身當然不像健康問題——它是我們自己問出來的答案。要判斷的是
        # 前一輪那張電視畫面，而那一輪已經被 guardrail 放行過了。條件很窄：
        # 對話裡必須真的有一張帶標題的電視新聞畫面（見 _previous_tv_news_headline）。
        answering_tv_news = bool(
            _tv_news_channel_answer(user_input)
            and _previous_tv_news_headline(state["messages"])
        )

        guardrail_task = (
            None
            if answering_tv_news
            else asyncio.create_task(self._guardrail_service.allow_rag_tool(user_input))
        )
        # 選工具的那次 LLM 呼叫也在這裡起跑（理由見 _start_speculative_decision）。
        # 急迫度仍然先判、判緊急就整個丟掉：安全檢查還是排在 agent 前面，
        # 只是模型不用等它。
        predecided, speculative = self._start_speculative_decision(state)
        try:
            verdict = await self._classify_urgency(user_input, language)
        except BaseException:
            _abandon_task(guardrail_task)
            _abandon_task(speculative)
            raise

        if verdict.is_emergency:
            # 緊急短路：guardrail 還在跑就取消，跑完了也不看。allow_rag 給 False
            # 只是讓 state 有值——emergency_node 根本不掛工具。
            _abandon_task(guardrail_task)
            _abandon_task(speculative)
            speculative = None
            predecided = None
            allow_rag = False
        elif guardrail_task is None:
            allow_rag = True
        else:
            try:
                allow_rag = await guardrail_task
            except BaseException:
                _abandon_task(speculative)
                raise

        log_stage(
            logger,
            "guardrail",
            allow_rag=allow_rag,
            tv_news_answer=answering_tv_news or None,
            urgency=verdict.level if verdict.is_emergency else None,
            # 緊急時 guardrail 被放掉，ms 量的只有急迫度那一段；沒有這個欄位會
            # 把「guardrail 很快」與「根本沒等它」混在一起。
            guardrail_skipped=True if verdict.is_emergency else None,
            ms=int((time.perf_counter() - t0) * 1000),
        )
        return {
            "allow_rag": allow_rag,
            "urgency": verdict,
            "speculative_decision": speculative,
            "predecided": predecided,
        }

    def _pre_llm_decision(
        self, state: State, tool_names: list[str], user_text: str
    ) -> AIMessage | None:
        """agent 節點問模型之前的幾條決定性捷徑；有一條成立就不必問模型。"""
        followup_call = _tv_news_channel_followup(state, tool_names, user_text)
        if followup_call is not None:
            return followup_call
        tv_news_call = _tv_news_claim_call(state, tool_names, user_text)
        if tv_news_call is not None:
            return tv_news_call
        card_call = _health_card_claim_call(
            state, tool_names, user_text
        ) or _health_card_rag_followup(state, tool_names, user_text)
        if card_call is not None:
            return card_call
        if self._local_rag_shortcut(state, tool_names, user_text):
            return _original_text_rag_call(user_text, "shortcut_rag_1")
        return None

    def _start_speculative_decision(
        self, state: State
    ) -> tuple[AIMessage | None, "asyncio.Task | None"]:
        """在 guardrail 節點還在等判斷的時候，先把「選工具」的 LLM 呼叫排進去。

        線上 14 天（2026-09-08～22，319 則）guardrail 節點 p50 2.6 秒、選工具
        p50 2.7 秒，兩段串起來每則都要等。兩者其實沒有資料依賴：模型選工具只
        看對話，guardrail 決定的是「RAG 這個工具給不給掛」。所以先假設會給
        （掛全部工具）問模型，等 guardrail 回來再對答案：

        - 放行 → 直接用，省下 min(guardrail, 選工具) 的時間。
        - 不放行、且模型沒選到被收掉的工具 → 仍可用：那個決定在縮小的工具集
          裡同樣合法。
        - 不放行、模型偏偏選了 RAG → 丟掉、照舊再問一次（agent_node 處理）。
          代價是一次白問；線上 36% 的訊息被擋，其中又只有一部分會選 RAG。
        - 判緊急 → 丟掉（guardrail_node 處理）。線上 5%。

        回 (predecided, task)：捷徑（電視新聞、圖卡、本地 RAG 分流）在這裡就
        判得出來時回 predecided、不起任務——本地分流會把過半的健康問題直接送
        RAG，那些訊息問模型是純浪費。
        """
        if any(isinstance(m, ToolMessage) for m in state["messages"]):
            return None, None
        # 捷徑與模型呼叫都假設 RAG 會放行；agent_node 拿到實際的 allow_rag
        # 之後再決定能不能沿用（見 agent_node）。
        assumed = {**state, "allow_rag": True}
        tools = get_all_tools(include_rag_tool=True)
        tool_names = [t.name for t in tools]
        user_text = _latest_human_text(state["messages"])
        predecided = self._pre_llm_decision(assumed, tool_names, user_text)
        if predecided is not None:
            return predecided, None
        task = asyncio.create_task(self._invoke_llm(assumed, tools))
        # 起了就一定要有人取例外：agent 被總逾時取消時這個任務可能沒人 await。
        task.add_done_callback(_consume_task_exception)
        return None, task

    async def _invoke_llm(self, state: State, tools: list) -> AIMessage:
        llm_with_tools = self._llm.bind_tools(tools)
        user_profile_text = format_user_profile_prompt(state.get("user_profile"))
        language = self._resolve_user_language(state.get("user_profile"))
        # 日期接在固定規則之後：模型要把「昨天」「禮拜一」換成查服藥狀況的 days_ago。
        full_prompt = build_system_prompt(language) + build_date_context() + user_profile_text
        messages = [SystemMessage(content=full_prompt)] + state["messages"]
        return await llm_with_tools.ainvoke(messages)

    async def _classify_urgency(self, user_input: str, language: str) -> UrgencyVerdict:
        if self._urgency_classifier is None:
            return NOT_URGENT
        return await self._urgency_classifier.classify(user_input, language=language)

    async def emergency_node(self, state: State) -> dict:
        """
        急迫度短路節點。直接產生緊急卡，不進 agent、不跑 RAG、不呼叫任何工具。

        內容是要原樣送往 LINE 的 Flex JSON，因此 agent.py 的後置處理必須整段
        跳過它——在 Flex JSON 後面接任何文字都會讓它不再是合法 JSON。

        行動先到：這裡只用判定組卡，不辨識人物、不查族譜、不準備通知。那些都在
        紅卡送出之後由 LINE handler 處理（見 _schedule_emergency_followup），
        所以卡片用語是中性的，不假設出事的是發話者本人。
        """
        # 只有判定為緊急才會走到這裡；判定遺失時仍出卡，不讓紅卡因狀態缺欄位而消失。
        verdict = state.get("urgency") or UrgencyVerdict(level=URGENCY_EMERGENCY)
        payload = json.dumps(
            build_emergency_condition_flex(verdict), ensure_ascii=False
        )
        log_stage(logger, "emergency_card", display=verdict.display or None)
        return {"messages": [AIMessage(content=payload)]}

    async def agent_node(self, state: State) -> dict:
        """LLM 決策節點：根據 allow_rag 動態綁定工具，讓 LLM 決定回話或呼叫工具。"""
        tools = get_all_tools(include_rag_tool=state.get("allow_rag", False))
        tool_names = [t.name for t in tools]
        user_text = _latest_human_text(state["messages"])
        # guardrail 節點先起跑的決定，只在這一輪的第一步用得到；取出後一律清掉。
        predecided = state.get("predecided")
        speculative = state.get("speculative_decision")
        consumed = {"predecided": None, "speculative_decision": None}

        # 放行時工具集與 guardrail 節點假設的相同：那邊判過的捷徑結論不變，
        # 不必（也不該）再判一次——再判會把 rag_route_local 多記一行。
        already_checked = bool(state.get("allow_rag")) and (
            predecided is not None or speculative is not None
        )
        if predecided is not None and already_checked:
            return {"messages": [predecided], **consumed}

        pre = None if already_checked else self._pre_llm_decision(state, tool_names, user_text)
        if pre is not None:
            _abandon_task(speculative)
            return {"messages": [pre], **consumed}

        t0 = time.perf_counter()
        response = None
        speculation = None
        if speculative is not None:
            response = await self._take_speculative_decision(speculative, tool_names)
            speculation = "hit" if response is not None else "miss"
        if response is None:
            response = await self._invoke_llm(state, tools)
        tool_calls = getattr(response, "tool_calls", None) or []
        force_rag = False
        force_upload = False
        force_location = False
        force_nearby = False
        force_official_site = False
        shared_location = _parse_shared_location(user_text)

        # 使用者已分享位置（prompt 規則 5(b)）。這裡必須是決定性的：模型若沒有
        # 主動呼叫 find_nearby_hospitals，agent 會回傳空內容，使用者只看到
        # 「抱歉，我無法理解您的問題」；allow_rag 為真時更會把座標文字當成
        # RAG 查詢送出去。順序排在 5(a) 之前 —— 已有座標就不該再要位置。
        if (
            not tool_calls
            and not _already_used_location_tools(state["messages"])
            and shared_location is not None
        ):
            lat, lng = shared_location
            # 使用者稍早若指定過科別（「附近有腸胃科嗎」），座標進來時必須沿用，
            # 否則會退化成搜尋所有科別，回傳一堆牙科、婦產科。
            departments = _extract_department_from_history(state["messages"])
            # 類型（大醫院／診所／藥局）與科別是各自獨立的維度，需分開判斷，
            # 兩者可同時帶入同一次工具呼叫（見 _facility_type_intent 的說明）。
            facility_type = _extract_facility_type_from_history(state["messages"])
            if departments:
                forced_tool_name = "find_nearby_facilities_by_department"
                forced_args = {"lat": lat, "lng": lng, "departments": departments}
            else:
                forced_tool_name = "find_nearby_hospitals"
                forced_args = {"lat": lat, "lng": lng}
            if facility_type:
                forced_args["facility_type"] = facility_type
            # 「現在有開的」與科別、類型各自獨立，可單獨成立也可同時成立。
            if _wants_open_now_from_history(state["messages"]):
                forced_args["open_now"] = True
            response = AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": forced_tool_name,
                        "args": forced_args,
                        "id": "forced_nearby_1",
                        "type": "tool_call",
                    }
                ],
            )
            tool_calls = response.tool_calls
            called = [forced_tool_name]
            force_nearby = True
        elif (
            not tool_calls
            and not _already_ran_official_site(state["messages"])
            and _is_official_site_intent(user_text)
        ):
            response = AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "open_official_site",
                        "args": {},
                        "id": "forced_official_site_1",
                        "type": "tool_call",
                    }
                ],
            )
            tool_calls = response.tool_calls
            called = ["open_official_site"]
            force_official_site = True
        elif (
            not tool_calls
            and not _already_used_location_tools(state["messages"])
            and _is_nearby_facility_intent(user_text)
        ):
            response = AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "request_location_quick_reply",
                        "args": {},
                        "id": "forced_location_1",
                        "type": "tool_call",
                    }
                ],
            )
            tool_calls = response.tool_calls
            called = ["request_location_quick_reply"]
            force_location = True
        elif (
            not tool_calls
            and _is_uploaded_document_question(user_text)
            and "answer_from_uploaded_document" in tool_names
            and not _already_ran_upload_document(state["messages"])
        ):
            response = AIMessage(
                content="",
                tool_calls=[
                    {
                        "name": "answer_from_uploaded_document",
                        "args": {"query": user_text},
                        "id": "forced_upload_1",
                        "type": "tool_call",
                    }
                ],
            )
            tool_calls = response.tool_calls
            called = ["answer_from_uploaded_document"]
            force_upload = True
        elif not tool_calls and _can_send_original_text_to_rag(state, tool_names, user_text):
            response = _original_text_rag_call(user_text, "forced_rag_1")
            tool_calls = response.tool_calls
            called = ["get_rag_answer"]
            force_rag = True
        else:
            called = [tc.get("name") for tc in tool_calls if isinstance(tc, dict)]

        log_stage(
            logger,
            "agent_decide",
            # 同一個 node 一輪會跑兩次：先決定要不要用工具，工具回來後再組最終
            # 回覆。兩次都記成 agent_decide 就分不開，而兩者的成本差很多——
            # 實測決定 1.3-1.5s、組回覆 1.8-2.5s。後者是在重寫 get_rag_answer
            # 已經寫好的答案，agent.py 甚至要防它掉來源或偽造來源。
            after_tools=any(
                isinstance(m, ToolMessage) for m in state["messages"]
            ),
            tools=tool_names,
            call=called or None,
            force_rag=force_rag or None,
            force_upload=force_upload or None,
            force_location=force_location or None,
            force_nearby=force_nearby or None,
            force_official_site=force_official_site or None,
            # hit＝用了 guardrail 期間先問好的答案；miss＝先問的選到被收掉的
            # 工具或失敗、重問了一次；沒有這個欄位＝這一步沒有投機（工具後的
            # 組回覆那一步一定沒有）。
            speculation=speculation,
            ms=int((time.perf_counter() - t0) * 1000),
        )

        return {"messages": [response], **consumed}

    async def _take_speculative_decision(
        self, task: "asyncio.Task", tool_names: list[str]
    ) -> AIMessage | None:
        """拿先問好的答案；用不了就回 None 讓呼叫端照舊再問。

        用不了的情況：模型選了這一輪沒提供的工具（guardrail 沒放行 RAG，模型
        卻選了 get_rag_answer）——沿用會讓 _execute_offered_tools 攔下它、模型
        再繞一圈；直接重問比較快也比較乾淨。任務失敗也一樣重問，讓正常路徑
        的錯誤處理接手。
        """
        try:
            response = await task
        except Exception:
            logger.warning("speculative_decision_failed; asking again", exc_info=True)
            return None
        offered = set(tool_names)
        for call in getattr(response, "tool_calls", None) or []:
            if isinstance(call, dict) and call.get("name") not in offered:
                return None
        return response
