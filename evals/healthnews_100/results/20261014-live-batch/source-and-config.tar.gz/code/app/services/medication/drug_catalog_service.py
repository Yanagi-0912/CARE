"""藥證庫比對。

存在的理由只有一個：偵測視覺模型的錯讀。模型把「脈優錠」讀成形近的其他藥名時，
它自述的信心度仍然很高，唯一能發現該字串不對應任何一張核准藥證的方法，
就是拿去跟外部字典比對。比對不到即降為低信心，強制人工核對。

建構子接受已載入的條目而非路徑，測試才能直接餵小型固定資料集，
不必碰檔案系統，也不必 monkey patch。

比對分兩個階段（依序，第一階段有命中就不再往下）：

1. 完全比對 ∪ 含容比對：查詢字串等於某個鍵（完全比對），聯集上品名
   包含這個查詢字串的所有鍵（含容比對，方向不拘：查詢是候選的子字串，
   或候選是查詢的子字串）。這兩者要聯集成同一份候選集合、一起交給
   `_resolve` 判定唯一性，不能讓完全比對單獨決定答案——藥袋通常只印
   短的品牌名（「普拿疼」），藥證上卻是連劑型、劑量都在內的全名
   （「普拿疼錠500毫克」），但這個短名本身也可能剛好等於**另一張**
   藥證的完整品名（「得胎隆」完全比對只中一張，另有 3 張品名包含它，
   例如「亞培」得胎隆膜衣錠10毫克）。只看完全比對會把後者的存在視而
   不見，讓一次精準但仍有多個可能的命中，看起來像已經確定——這正是
   score 1.0 卻比錯藥證的主因，見 DrugCatalogMatch 的說明。
   （單純用 SequenceMatcher 比長度差懸殊的兩個字串，比值會被長度差
   拉低到任何門檻都分不開「這是同一顆藥的縮寫」跟「這是兩個不相干的
   字串」——實測 '普拿疼' 對 '普拿疼錠500毫克' 只有 0.500——含容比對
   繞過這個問題：直接檢查子字串關係。）
2. 模糊比對：完全比對與含容比對都沒有任何命中時，對候選做
   SequenceMatcher，取門檻以上的最高分對應的鍵。**模糊命中只用來驗證
   藥名，永遠不確定身分**：回傳的 `license_number` 一律為 None、
   `candidates` 一律為空，理由見 `_match_by_fuzzy`。

含容比對與模糊比對的候選集合都來自同一份字元 n-gram 反向索引（建構子
裡建一次），不再對全部鍵做線性掃描——這是修正「模糊比對未命中時卡住
事件迴圈 400~750ms」缺陷的根本作法，細節見各方法的說明。查詢長度低於
`_MIN_CONTAINMENT_LENGTH` 時跳過含容比對（不查 n-gram 索引），只看
完全比對是否命中，避免極短查詢把半個藥證庫都拉進候選。

含容比對的兩個方向完整度不對稱，用兩種不同機制：「查詢是候選鍵的
子字串」由 n-gram 交集完整覆蓋（候選鍵必然含有查詢的每一個 gram，
見 `_candidates` 的說明）。「候選鍵是查詢的子字串」原本想用同一套
gram 索引近似（聯集查詢裡罕見的 gram），但驗證後發現這條路徑無法
被「provably 完整」：候選鍵越短、或候選鍵自己的 gram 在全庫剛好都很
常見，就會被系統性地漏掉——真實案例：食藥署藥品許可證庫裡有藥證
單獨以劑型或成分名稱掛證，中文的如「注射液」「膜衣錠100毫克」，
英文的如單獨掛證的原料藥名「TESTOSTERONE」「TESTOSTERONEPROPIONATE」，
長度從 2 字到 20 幾字都有，沒有一個長度上限能同時「provably 涵蓋
全部案例」又「窮舉集合夠小」。這個方向因此改用前綴分桶的精確多模式
比對（`_reverse_containment_hits`），不靠任何長度上限或頻率近似，
數學上保證找到每一個真正的子字串候選，見該方法的說明。

兩個方向的完整度補齊之後，還有另一件事不對稱：**證據力**。「查詢是
候選鍵的子字串」代表查詢字串整個對應到一張真實登記品名的一部分，是
「這是真實藥名」的證據；「候選鍵是查詢的子字串」只代表查詢字串裡
剛好包含某個登記過的片段（常見的是「膠囊」「膜衣錠」這類劑型名稱），
任何字串——包含模型讀錯、甚至完全虛構的藥名——只要恰好含有這類短詞
就會湊出這種命中，不構成「查詢字串本身是真實藥名」的證據。這條規則
有兩半，兩半都要成立：

1. **不能單獨建立驗證結果**：沒有 exact、也沒有 forward 命中時，即使
   reverse 命中非空，`match()` 仍回傳 None，見該方法的判斷式。
2. **不能成為可挑選的候選**：reverse 命中只能用來**拆掉**已經成立的
   唯一性（讓 `license_number` 留空），不得出現在 `candidates` 裡。
   `candidates` 是拿給使用者挑、且挑中就會貼上藥丸照片的清單，它的
   安全性建立在「候選皆受藥名約束，錯的候選仍是同名藥品」這個前提上
   （design.md 的 Risks）；reverse 命中按這個模組自己的定義就是**別的
   藥**——只是碰巧有個登記過的片段落在查詢字串裡。實測全庫 56,886 個
   中文品名，若把 reverse 命中一起放進 `candidates`，有 429 個藥名
   （0.75%）畫面上每一張照片都屬於別的藥、使用者自己那顆一張都沒有
   （「欲胃能錠」只有「胃能錠」有照片；「康保酊（辣椒酊）」只有
   「"明通" 辣椒酊」有照片），排除 reverse 後降到 233 個，剩下的全是
   forward 命中的同名藥品家族（不同廠牌或劑量），那是 spec 明訂的預期
   行為。這跟模糊路徑一律不帶候選是同一條理由，見 `_match_by_fuzzy`。

因此「唯一性判定用的集合」與「可挑選的候選集合」是兩份不同的集合：
前者是 exact ∪ forward ∪ reverse，後者只有 exact ∪ forward，
由 `_resolve` 分別承接，見該方法的說明。實測這個切分不改變任何一個
藥名的釘證結果（全庫 56,886 個中文品名，`license_number` 變動數為 0），
拿掉的只有「別的藥可以被挑」。

同一把尺量下去，**模糊命中的證據力比 reverse 更弱**：查詢字串在全庫
連一個字面命中都沒有，只是「長得像」某個鍵。它足以支撐藥名驗證（這正
是模糊比對存在的理由：把模型讀錯一個字的藥名救回來），但完全不足以
指認身分——所以模糊路徑一律不回傳 `license_number`、也不回傳候選，
見 `_match_by_fuzzy`。
"""

import json
import logging
import re
import unicodedata
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Iterable, Optional

logger = logging.getLogger(__name__)

# 藥證品名常見的廠商前綴：'"福元"蘇打錠500毫克'。藥袋上通常只印藥名，
# 不會帶這段，所以正規化時要拿掉。全形與半形引號都要涵蓋。
_LEADING_MANUFACTURER = re.compile(r'^\s*[「『"“”‘’](.*?)[」』"“”‘’]\s*')
_QUOTE_CHARS = re.compile(r'[「」『』"“”‘’\']')
_WHITESPACE = re.compile(r"\s+")

# 字元 n-gram 的大小。中文藥名的資訊密度高，2 字已有足夠鑑別度；
# 選太大會讓短於這個長度的查詢字串連一個 gram 都湊不出來。
_GRAM_SIZE = 2

# 含容比對的最小查詢長度。低於這個長度時，任何字串幾乎都會是某個藥證
# 品名的子字串（例如單一個「錠」字），含容比對會失去意義、變成幾乎
# 全部命中，所以短於此長度一律跳過含容比對，直接落到模糊比對。
_MIN_CONTAINMENT_LENGTH = 3

# 候選集合聯集「查詢裡最罕見的一個 gram」時，該 gram 的 postings 長度
# 上限。常見 gram（英文藥名裡到處都是的 'ER'、'TA'，中文的「膜衣」
# 「錠」）postings 可能長達數萬筆，若不設上限，聯集等於又把全庫掃了
# 一遍，索引就白建了。超過上限就不聯集這個 gram——含容比對用的是
# 交集（見 `_candidates` 的說明），不依賴這一步也能找到主要方向的
# 候選；這一步只是額外補反方向與模糊比對的召回率。
_MAX_RARE_GRAM_POSTINGS = 3000

# 括號補述。藥證品名的括號裡慣例是成分名或劑型補述
# （「ANROKIN TABLETS (CHLORZOXAZONE)」「便通樂錠（番瀉/）」）。藥袋上這段
# 常被截斷，而模型會把看到的殘缺括號「補上」右括號——結果是一個藥證庫裡
# 不存在的字串：`ANROKIN TABLETS (CHLORZOXA` 是真實品名的子字串所以命中，
# `ANROKIN TABLETS (CHLORZOXA)` 因為那個右括號就什麼都比不到。
_PARENTHETICAL_ANY = re.compile(r"[(（][^)）]*[)）]?")

# 拉丁字母與中日韓文字的連續段。藥袋常把英文品牌與中文品名印在一起
# （「VORTAGEN莫得炎腸溶微粒膠囊」），但藥證庫的 name_zh 與 name_en 是兩個
# 獨立欄位，這種混合字串在任何一邊都不是子字串。
_LATIN_RUN_RE = re.compile(r"[A-Z0-9][A-Z0-9./+-]*")
_CJK_RUN_RE = re.compile(r"[一-鿿぀-ヿ]+")

# 衍生查詢的最小長度。太短的片段（單一個「錠」、兩個字母的縮寫）拿去比對
# 只會把半個藥證庫拉進候選，與 `_MIN_CONTAINMENT_LENGTH` 同一個道理。
_MIN_VARIANT_LENGTH = 3

# 分段比對（`_match_by_segments`）用的切分規則。醫院藥袋把一顆藥印成
# 「英文品牌 含量 (學名) 中文品名」，還常夾著顏色、管制分級、廠商：
# 「Nexium 40mg棕紅(Esomeprazole) 耐適恩錠 Esomeprazole」。
#
# 含量：數字加單位，連同「/tab」「/puff」這類每單位的分母一起拿掉。含量
# 單獨拿去比對時會命中上千張藥證（「40mg」556 張、「500mg」1,293 張），
# 不帶任何品項資訊。前面接著字母的數字不算（「B12」是品名的一部分）。
_STRENGTH_RE = re.compile(
    r"(?<![A-Z])(?P<value>\d+(?:\.\d+)?)\s*"
    r"(?P<unit>MCG|ΜG|UG|MG|G|ML|IU|%|微公克|微克|毫克|公絲|公克|毫升|公撮)?"
    r"(?:\s*/\s*[A-Z一-鿿]+)?"
)
# 換算成毫克的倍率，只收質量單位。含量只拿來否決釘選（見
# `_strengths_conflict`），所以換算不了的單位（ML、IU、%）直接不參與。
_MG_PER_UNIT = {
    "MG": 1.0, "毫克": 1.0, "公絲": 1.0,
    "MCG": 0.001, "ΜG": 0.001, "UG": 0.001, "微克": 0.001, "微公克": 0.001,
    "G": 1000.0, "公克": 1000.0,
}
# 分隔符號：空白、括號、標點、商標符號與各式引號（廠商名常用〝〞括起來）。
# 不在這裡、也不是拉丁字母數字或中日文的字元，一律讓分段比對整個放棄——
# 只有認得的雜訊才能丟，見 `_segments`。
_SEGMENT_SEPARATOR_RE = re.compile(
    r"[\s()（）\[\]【】{}<>《》,，、;；:：/*+&.。!！?？#=_~·・®™'\"“”‘’〝〞「」『』]+"
)
_SEGMENT_RUN_RE = re.compile(r"[A-Z0-9-]+|[一-鿿぀-ヿ]+")
# 英文的劑型與劑量單位字（「0.25 mg/tab」「SALONPAS ... PATCH」）。中文劑型
# 另外從藥證庫的「劑型」欄建（見 `_form_keys`）。劑型字在全庫最不具鑑別力
# （「TAB」是 20,397 張藥證的子字串），它代表「這是一種錠劑」，不代表是
# 哪一顆藥，因此不能投票——拿去投票只會讓英文品名碰巧寫 TABLETS 的藥證勝過
# 寫 CAPLETS 或只有中文品名的同名藥。
_DOSAGE_FORM_WORDS = frozenset(
    {
        "TAB", "TABS", "TABLET", "TABLETS", "CAP", "CAPS", "CAPSULE", "CAPSULES",
        "CAPLET", "CAPLETS", "SYRUP", "INJ", "INJECTION", "SOLUTION", "SUSPENSION",
        "CREAM", "OINTMENT", "GEL", "LOTION", "PATCH", "DROPS", "POWDER", "GRANULES",
        "SPRAY", "SUPPS", "FILM-COATED",
    }
)


@dataclass(frozen=True)
class DrugCatalogEntry:
    license_number: str
    name_zh: str
    name_en: str = ""
    # 外觀欄位（來自食藥署藥品外觀資料集，見 scripts/build_drug_catalog.py）：
    # 無外觀記錄的藥證全部留空字串，不是 None——呼叫端不必先判斷型別
    # 才能安全串接顯示。原樣帶過原始資料，不在這裡正規化（例如 score_line
    # 常是字面上的「無」，color 可能是「黃;;;白」），正規化是呈現面的事。
    image_url: str = ""
    shape: str = ""
    color: str = ""
    score_line: str = ""
    mark_one: str = ""
    mark_two: str = ""
    size: str = ""
    # 藥事法第 8 條的分級：prescription／otc_guided／otc／not_a_medicine，
    # 或空字串（對照表認不得的類別、以及只出現在外觀資料集的品項）。
    # 空字串在下游一律不觸發成分重複偵測——寧可少偵測，不要對一個我們不知道
    # 是什麼的東西發警報。
    drug_class: str = ""
    # 劑型（食藥署「劑型」欄，見 scripts/build_drug_catalog.py）。用途只有一個：
    # 讓成分重複偵測把局部作用劑型排除在比對之外（見
    # `ingredient_overlap.load_local_action_forms`）。這個欄位曾經漏掉而
    # `_to_view` 用 `getattr(entry, "dosage_form", "")` 取值，於是線上永遠取到
    # 空字串、排除從未生效——單元測試用的假 entry 自己帶了這個欄位，因此測試
    # 一直是綠的。預設空字串而非 None，理由與 `ingredients` 相同。
    dosage_form: str = ""
    # 正規化後的主成分清單（英文學名，已去括號補述）。用學名而非中文品名比對，
    # 因為普拿疼、斯斯、明通治痛丹的品名毫無交集，主成分都是 ACETAMINOPHEN。
    #
    # 預設空 tuple 而非 None：舊版 drug_catalog.json 沒有這個欄位時，呼叫端
    # 拿到的是「沒有成分資料」而不是型別錯誤。部署順序不保證程式碼與產出物
    # 同時更新，這裡拋錯會讓整個藥袋掃描掛掉，那比沒有這個功能糟得多。
    ingredients: tuple[str, ...] = ()
    # 該張藥證的 ATC 藥理治療分類碼（食藥署 dataset 9119，見
    # scripts/build_drug_catalog.py 的 `_index_atc_codes`）。已去重排序。
    #
    # 用途是回答「這張藥證屬不屬於某個藥理類別」——成分名稱做不到這件事：
    # 要判斷一個藥是不是苯二氮平類，靠成分字串得先窮舉所有苯二氮平的名字，
    # 靠 ATC 只要看代碼是否以 N05BA 起頭。
    #
    # 粒度不一致，前綴比對時要注意：以藥證計，99% 至少有一個 ≥5 碼、
    # 93% 至少有一個 7 碼，但仍有約 1% 只掛到 3～4 碼的群組層級。
    #
    # 預設空 tuple 而非 None，理由與 `ingredients` 相同：舊版
    # drug_catalog.json 沒有這個欄位時，呼叫端拿到的是「沒有分類資料」
    # 而不是型別錯誤。實測覆蓋率 58.4%，查無本來就是常態。
    atc_codes: tuple[str, ...] = ()


@dataclass(frozen=True)
class DrugCatalogMatch:
    """藥名比對結果。

    `license_number` 是 Optional，這個 None 代表候選集合裡有不只一張
    藥證字號。候選集合是「完全比對命中的鍵」跟「品名包含查詢字串的鍵」
    的**聯集**——兩者缺一都會漏掉真正的歧義：只看完全比對，會漏掉查詢
    字串剛好也是另一張藥證全名一部分的情形（「得胎隆」完全比對只中
    一張，但另有 3 張品名包含它，例如「亞培」得胎隆膜衣錠10毫克，
    真正在藥袋上的可能是後者）；只看含容比對，則會漏掉查詢字串自己
    就精準等於另一張藥證品名的情形（「普拿疼」同時是好幾個普拿疼系列
    產品品名的子字串）。**完全比對命中（`score == 1.0`）不是例外**：
    查詢字串跟某個鍵逐字相同，只代表這個字串本身是一個真實藥名，不
    代表消除了歧義——「感冒液」完全比對命中時就對應 41 張藥證。這種
    情況下藥名本身已經被驗證為真實存在、核准過的藥品——這正是本比對
    唯一的存在理由——只是不知道對應哪一個品項，因此不得任意選一個
    冒充答案（選第一個、選最短的、甚至選 score 最高的都是編造），
    寧可留空也不要讓使用者的用藥提醒掛上一個他根本沒有被開立的藥證
    字號。

    `candidates` **不是**上面那個聯集，是它的一個子集：只含完全比對與
    正向含容命中的藥證（依 license_number 去重），供呼叫端在唯一時直接
    用、在多筆時交給使用者挑一個。反向含容命中（品名是查詢字串子字串的
    那些藥證）算進唯一性判定、卻不列入 `candidates`——它們按定義是別的
    藥，不能拿給使用者挑，理由與量測見模組文件「證據力」那一段。
    因此 `len(candidates) == 1` **不蘊含** `license_number` 有值：這代表
    「只有一張藥證有資格被挑，但庫裡還有別的可能」，呈現面必須把它當成
    「請使用者確認」而不是「已確定」（見 LIFF 的 `DrugCandidateSection`）。
    反向的蘊含仍然成立：`license_number` 有值時 `candidates` 必然剛好
    一筆，見 `_resolve`。

    呼叫端判斷「這個藥名有沒有通過藥證庫校驗」必須看 `match()` 的回傳
    值是不是 None，而不是看 `license_number` 是不是 None——後者只表示
    「知不知道是哪一張藥證」，是校驗結果之外的另一個維度，把兩者混在
    一起會讓含容或完全比對命中但無法定位品項的藥名被誤判成未驗證，
    重新強制走人工核對，抵銷了候選機制原本要解決的問題。
    """

    license_number: Optional[str]
    name_zh: str
    name_en: str
    score: float
    candidates: list[DrugCatalogEntry] = field(default_factory=list)


def normalize_drug_name(name: str) -> str:
    """把藥名收斂成可比對的鍵。

    全形轉半形、去引號與廠商前綴、去除空白、統一大小寫。這些差異在藥袋與
    藥證之間普遍存在，不正規化會讓大量正確的藥名比對不到。
    """
    if not name:
        return ""
    # NFKC 一併處理全形英數與全形空白
    normalized = unicodedata.normalize("NFKC", name)
    normalized = _LEADING_MANUFACTURER.sub("", normalized)
    normalized = _QUOTE_CHARS.sub("", normalized)
    normalized = _WHITESPACE.sub("", normalized)
    return normalized.upper()


def _strengths_mg(text: str) -> frozenset[float]:
    """字串裡帶質量單位的含量，換算成毫克。沒有單位的數字不算。"""
    normalized = unicodedata.normalize("NFKC", text).upper()
    values = set()
    for found in _STRENGTH_RE.finditer(normalized):
        factor = _MG_PER_UNIT.get(found.group("unit") or "")
        if factor is not None:
            values.add(round(float(found.group("value")) * factor, 6))
    return frozenset(values)


def _strengths_conflict(printed_mg: frozenset[float], entry: "DrugCatalogEntry") -> bool:
    """藥袋與藥證品名都寫了質量含量、卻沒有任何一個相同。一邊沒寫就不算衝突。"""
    registered_mg = _strengths_mg(f"{entry.name_zh} {entry.name_en}")
    return bool(printed_mg and registered_mg and not printed_mg & registered_mg)


@dataclass(frozen=True)
class _Segmentation:
    """`DrugCatalogService._segments` 的結果。"""

    segments: list[str]
    # 丟掉了帶字母或中文的短片段。它們多半是顏色、管制分級或廠商，但也可能
    # 是版本字（「XL」「CR」「二號」），無從分辨，因此有丟時不釘證號。
    dropped_words: bool
    strengths_mg: frozenset[float]


def _has_identifying_content(key: str) -> bool:
    """鍵是否至少含有一個英數字或中日韓文字。

    原始資料裡混著純標點符號的資料瑕疵——整個品名就是「.」或「*」，
    這種鍵不具任何辨識力，卻會在反方向含容比對裡跟任何帶有這個符號的
    字串（例如英文縮寫的句點 "F.C. TABLETS"）湊出虛假的子字串命中：
    實測全庫正規化後的 112,230 個鍵裡只有這兩個純標點鍵（排除後
    `_by_key` 剩 112,228 個），但其中「.」單獨掛的
    那張證號（一款乾洗手液）讓抽樣的英文藥名裡有 88% 因為名稱帶句點
    而被拖進候選、平白失去原本能確定的證號。這種鍵在建索引時就該
    整個排除，而不是等到查詢時才特別處理。
    """
    return any(ch.isalnum() for ch in key)


def _ngrams(key: str, size: int = _GRAM_SIZE) -> set[str]:
    """把字串切成字元 n-gram 集合，供反向索引使用。

    長度不足一個 gram 的字串（正規化後只剩 1 個字，或空字串已在呼叫端
    擋掉）就把整個字串當成唯一的 gram——仍要能被索引到、被查到，不能
    因為太短就直接失去候選資格。
    """
    if not key:
        return set()
    if len(key) < size:
        return {key}
    return {key[i : i + size] for i in range(len(key) - size + 1)}


class DrugCatalogService:
    def __init__(self, entries: Iterable[DrugCatalogEntry], threshold: float):
        self._entries = list(entries)
        self._threshold = threshold
        # 證號 → 條目。同一證號在來源資料裡只會有一筆（建表腳本以證號去重），
        # 重複時取第一筆，與 `_index_appearance_fields` 的既有規則一致。
        self._by_license_number: dict[str, DrugCatalogEntry] = {}
        for entry in self._entries:
            self._by_license_number.setdefault(entry.license_number, entry)
        # 正規化後的鍵 → { license_number → 條目 }。同一條目的中英文品名
        # 各佔一個鍵。實測全庫 66,478 筆藥證產生 112,228 個鍵（已扣掉下面
        # 排除的純標點鍵），其中 10,765 個鍵對應到不只一張藥證，涉及 21,250
        # 張不重複藥證（**全庫 32.0%**，不是先前寫的 47%——那個數字把碰撞
        # 鍵上的「鍵×藥證」出現次數當成藥證張數重複計了），
        # 用 setdefault 只留第一筆會讓其餘藥證永遠比對不到——這裡改成
        # 集合，讓碰撞的每一筆都保留、都可觸達；「保留多筆」跟「回傳哪一筆」
        # 是兩件事，後者留給 `match()` 依候選數量決定（見 `_resolve`）。
        # 純標點符號的鍵（見 `_has_identifying_content` 的說明）在這裡就
        # 排除，不進 `_by_key`——它不具辨識力，留著只會讓下游的反方向
        # 含容比對把它當成任何帶有該符號之字串的「候選」。
        self._by_key: dict[str, dict[str, DrugCatalogEntry]] = {}
        for entry in self._entries:
            for raw_name in (entry.name_zh, entry.name_en):
                key = normalize_drug_name(raw_name)
                if key and _has_identifying_content(key):
                    self._by_key.setdefault(key, {})[entry.license_number] = entry

        # gram → 含這個 gram 的鍵集合。在建構子裡建一次；之後每次查詢
        # 都只查這份索引取候選，不再對 `_by_key` 做線性掃描。真實藥證庫
        # 有 11 萬多個鍵，每次未命中的查詢都線性掃一遍 SequenceMatcher
        # 需要 400~750ms，且 `scan()` 是 async 路徑，會卡住整個行程
        # （含用藥提醒排程器）——這份索引就是用來擋掉那個代價。
        self._gram_index: dict[str, set[str]] = {}
        for key in self._by_key:
            for gram in _ngrams(key):
                self._gram_index.setdefault(gram, set()).add(key)

        # 前綴分桶：鍵的前兩個字元 → 有這個前綴的全部鍵（長度不足 2 字的
        # 鍵另外存進 `_single_char_keys`）。供 `_reverse_containment_hits`
        # 做「候選鍵是查詢字串子字串」這個方向的精確多模式比對——任何
        # 鍵若真的從查詢字串某個位置開始逐字相同，它的前兩個字元必然
        # 等於查詢字串同一個位置的前兩個字元，所以只要對查詢的「每一個
        # 起始位置」查這份分桶，就保證不漏掉任何真正的子字串候選，不必
        # 對全庫線性掃描。實測 `_by_key` 的 112,228 個鍵（扣掉 3 個單字元
        # 鍵，有 112,225 個進得了分桶）只有 21,088 種不同的兩字前綴，
        # 桶的中位數只有 1 筆、最大 1,692 筆，遠比逐鍵掃描全庫便宜。
        self._by_prefix: dict[str, list[str]] = {}
        self._single_char_keys: set[str] = set()
        for key in self._by_key:
            if len(key) == 1:
                self._single_char_keys.add(key)
            else:
                self._by_prefix.setdefault(key[:2], []).append(key)

        # 學名鍵：全庫主成分的正規化字串，外加第一個字（「ESOMEPRAZOLE
        # MAGNESIUM TRIHYDRATE」的「ESOMEPRAZOLE」——藥袋只印鹽基前的學名）。
        # 分段比對用它認出哪一段是學名，見 `_match_by_segments`。
        self._ingredient_keys: set[str] = set()
        # 劑型鍵：「劑型」欄的值，外加去掉字尾「劑」的寫法（藥袋印「膠囊」、
        # 藥證寫「膠囊劑」）。同樣只給分段比對用。
        self._form_keys: set[str] = set(_DOSAGE_FORM_WORDS)
        for entry in self._entries:
            for ingredient in entry.ingredients:
                for form in (ingredient, ingredient.split(" ", 1)[0]):
                    key = normalize_drug_name(form)
                    if len(key) >= _MIN_VARIANT_LENGTH:
                        self._ingredient_keys.add(key)
            form_key = normalize_drug_name(entry.dosage_form)
            if form_key:
                self._form_keys.add(form_key)
                self._form_keys.add(form_key.removesuffix("劑"))

    def entry_by_license_number(self, license_number: str) -> Optional[DrugCatalogEntry]:
        """依許可證字號取條目。查無回 None。

        成分重複偵測需要的是「這張藥證的分級與主成分」，而掃描流程在使用者
        確認候選之後已經釘定了證號（`_resolved_candidate.license_number`），
        因此以證號查詢是最直接的路徑。

        刻意不把成分塞進 `DrugCatalogMatch`：那個結構同時用在候選清單上，
        每一筆候選都帶完整成分只會讓它變胖，而候選階段還沒釘定是哪一張藥證，
        成分本來就不該在那時被使用。
        """
        key = (license_number or "").strip()
        if not key:
            return None
        return self._by_license_number.get(key)

    @property
    def is_empty(self) -> bool:
        return not self._entries

    @classmethod
    def load_from_path(cls, path: str, threshold: float) -> "DrugCatalogService":
        """從靜態檔載入。

        檔案缺席或損毀時回傳空的服務而非拋錯：藥證庫不是啟動的必要條件，
        缺席的後果是所有藥名降為低信心（每份草稿都要人工核對），
        這個退化方向是安全的，讓應用起不來則不是。
        """
        try:
            with open(path, "r", encoding="utf-8") as catalog_file:
                raw_entries = json.load(catalog_file)
            entries = [
                DrugCatalogEntry(
                    license_number=item.get("license_number", ""),
                    name_zh=item.get("name_zh", ""),
                    name_en=item.get("name_en", ""),
                    # `.get(..., "")`：drug_catalog.json 是提交進 repo 的產出物，
                    # 舊 commit 產出的檔案沒有這些鍵，缺鍵時視為空字串而不是
                    # 讓載入失敗——外觀欄位是既有藥證資料的擴充，不是前提。
                    drug_class=item.get("drug_class", ""),
                    dosage_form=item.get("dosage_form", ""),
                    ingredients=tuple(item.get("ingredients") or ()),
                    atc_codes=tuple(item.get("atc_codes") or ()),
                    image_url=item.get("image_url", ""),
                    shape=item.get("shape", ""),
                    color=item.get("color", ""),
                    score_line=item.get("score_line", ""),
                    mark_one=item.get("mark_one", ""),
                    mark_two=item.get("mark_two", ""),
                    size=item.get("size", ""),
                )
                for item in raw_entries
            ]
            service = cls(entries, threshold=threshold)
            # 檔案存在、也成功解析成 JSON，不代表內容真的可用——欄位名稱對不上
            # FDA 資料集（例如改版換了欄位名）會讓每個 item.get(...) 都拿到
            # 空字串，最終得到一個「載入成功」但條目數是 0 或每筆都是空殼的
            # DrugCatalogService，之後所有藥名都悄悄降為低信心，卻沒有任何
            # 錯誤訊息能讓人發現問題出在資料，而不是模型辨識不準。
            if service.is_empty:
                logger.warning(
                    "藥證庫載入完成但條目數為 0，所有藥名將降為低信心並強制人工核對："
                    "%s；請確認 FDA 資料集欄位名稱與載入邏輯是否對得上",
                    path,
                )
            else:
                logger.info("藥證庫載入完成：%s，共 %d 筆條目", path, len(entries))
            return service
        except (OSError, ValueError, TypeError, AttributeError) as exc:
            logger.error(
                "藥證庫載入失敗，所有藥名將降為低信心並強制人工核對：%s（%s）",
                path,
                exc,
            )
            return cls([], threshold=threshold)

    def match(self, name: str) -> Optional[DrugCatalogMatch]:
        """比對藥名。主鍵定不出證號時，再試幾個衍生查詢。

        **衍生查詢不放寬任何證據規則**：每一個變體都走完全相同的
        `_match_key` 管線（完全比對 ∪ 含容比對 → 唯一性判定 → 模糊比對），
        改變的只是「拿哪個字串去問」。因此一個變體能定出證號，代表那個
        字串本身確實整個對應到一張真實登記品名的一部分——與主鍵命中時
        的證據力相同。

        **主鍵帶著候選時一律直接回傳，不試變體。** 判準是 `candidates` 非空，
        不是 `license_number` 有值：含容與完全比對會建立一個真實的唯一性集合
        （即使結果是「有 26 張、無法定位」），那個歧義是藥證庫本身就有的，
        不是查詢字串壞掉造成的——拿一個更短的字串去繞過它就是編造答案。

        實測這條界線是必要的：`INFLAMNIL TABLETS 100MG (TRIMETHOPRIM)` 的
        真候選集合有 26 張藥證，去掉括號後的主幹卻收斂成唯一——回傳那個
        唯一值會違反「證號唯一才可信」，正是 `test_index_matches_brute_force_
        at_real_catalog_scale` 要擋的假唯一。

        反過來，**模糊命中可以被變體取代**：模糊路徑依定義不帶候選、也永遠
        不釘證號（見 `_match_by_fuzzy`），它沒有提供任何唯一性資訊，因此用
        一個字面上真的能對到藥證的變體去取代它，不會繞過任何既有的歧義。
        這正是模型補上右括號那個案例——`ANROKIN TABLETS (CHLORZOXA)` 跟真實
        品名只差一個字元，模糊比對過得了，但那條路徑不給證號。

        實測動機見 `_query_variants`。
        """
        primary = self._match_key(normalize_drug_name(name))
        if primary is not None and primary.candidates:
            return primary

        for variant in self._query_variants(name):
            alternate = self._match_key(variant)
            if alternate is not None and alternate.license_number:
                return alternate

        split = self._match_by_script_split(name)
        if split is not None:
            return split

        segmented = self._match_by_segments(name)
        # 變體全部落空時回到主鍵的結果（可能是模糊命中的「藥名已驗證、
        # 身分不明」）——變體幫不上忙不該讓原本通過的藥名驗證消失。
        return segmented if segmented is not None else primary

    def _query_variants(self, name: str) -> list[str]:
        """主鍵定不出證號時要再試的衍生查詢，依序回傳、不含主鍵本身。

        目前只有一種：**去掉括號補述**。藥證品名的括號裡慣例是成分名
        （「ANROKIN TABLETS (CHLORZOXAZONE)」），藥袋上那段常被截斷，而
        模型會把殘缺的括號補上右括號，造出一個庫裡不存在的字串。去掉整個
        括號段之後剩下的品名主幹仍然是真實品名的子字串，含容比對就接得回來。

        去括號的方向是**變短**，因此候選只會變多不會變少——不可能讓一個
        原本沒有證據的查詢無中生有變成有證據，最壞情況是候選變多而唯一性
        被拆掉、證號留空，那與現況一致。
        """
        key = normalize_drug_name(name)
        if not key:
            return []
        stripped = normalize_drug_name(_PARENTHETICAL_ANY.sub("", key))
        if stripped and stripped != key and len(stripped) >= _MIN_VARIANT_LENGTH:
            return [stripped]
        return []

    def _match_by_script_split(self, name: str) -> Optional[DrugCatalogMatch]:
        """英文品牌與中文品名印在一起時，兩段各自比對後取交集。

        藥袋會印成「VORTAGEN莫得炎腸溶微粒膠囊」，但藥證庫的 `name_zh` 與
        `name_en` 是兩個獨立欄位，這個混合字串在任何一邊都不是子字串，
        因此主鍵必然落空。

        **取交集是收緊，不是放寬。** 這裡要求同一張藥證同時通過拉丁字段
        與中文字段兩次獨立驗證，比任何單一字串的命中證據都強——單獨拿
        `VORTAGEN` 去問會得到 4 張藥證（歧義），單獨拿中文品名去問是另一
        組，只有兩邊都指向的那一張才回傳，且仍要求交集後恰好一張。

        兩段都必須自己先通過 `_match_key` 的驗證（回傳非 None）：其中一段
        未驗證時整個放棄，不拿另一段的結果冒充答案。
        """
        key = normalize_drug_name(name)
        if not key:
            return None
        latin = "".join(_LATIN_RUN_RE.findall(key))
        cjk = "".join(_CJK_RUN_RE.findall(key))
        if len(latin) < _MIN_VARIANT_LENGTH or len(cjk) < _MIN_VARIANT_LENGTH:
            return None

        latin_match = self._match_key(latin)
        cjk_match = self._match_key(cjk)
        if latin_match is None or cjk_match is None:
            return None

        by_license = {
            entry.license_number: entry for entry in latin_match.candidates
        }
        shared = [
            by_license[entry.license_number]
            for entry in cjk_match.candidates
            if entry.license_number in by_license
        ]
        if len(shared) != 1:
            return None

        entry = shared[0]
        return DrugCatalogMatch(
            license_number=entry.license_number,
            name_zh=entry.name_zh,
            name_en=entry.name_en,
            # 分數取兩段的較小值：這個結果的可信度受較弱的那一段限制。
            score=min(latin_match.score, cjk_match.score),
            candidates=[entry],
        )

    def _segments(self, name: str) -> Optional[_Segmentation]:
        """把藥袋上的一整串藥名切成可以各自比對的段，已正規化、去重、保序。

        只丟得掉三種認得的雜訊：含量、分隔符號，以及短於
        `_MIN_VARIANT_LENGTH` 的片段——顏色（「棕紅」）、管制分級（「管4」
        「關」）、兩字的廠商名（「永信」）都落在最後一種，它們不在品名鍵裡，
        留著只會讓整串比不到。其他認不得的字元（別種文字、私人使用區）回傳
        None 讓分段比對整個放棄：把它們丟掉等於替一個不存在的藥名挑出剛好
        登記過的片段去問，正是模組文件「證據力」那段要擋的事。
        """
        text = unicodedata.normalize("NFKC", name).upper()
        strengths = _strengths_mg(text)
        text = _STRENGTH_RE.sub(" ", text)
        segments: list[str] = []
        dropped_words = False
        for piece in _SEGMENT_SEPARATOR_RE.split(text):
            runs = _SEGMENT_RUN_RE.findall(piece)
            if "".join(runs) != piece:
                return None
            for run in runs:
                key = normalize_drug_name(run)
                if key.replace("-", "").isdigit():
                    continue
                if len(key) < _MIN_VARIANT_LENGTH:
                    dropped_words = True
                elif key not in segments:
                    segments.append(key)
        return _Segmentation(segments, dropped_words, strengths)

    def _match_by_segments(self, name: str) -> Optional[DrugCatalogMatch]:
        """藥袋把品牌、含量、學名、中文品名印成一串時，逐段比對再合併。

        `_match_by_script_split` 把英文段全部接起來、中文段全部接起來各問
        一次，只要藥袋多印了含量、顏色或學名，接起來的字串就不存在於任何
        品名裡。線上 25 筆藥袋辨識結果有 8 筆因此整串比不到（2026-09-30），
        拆開後 8 筆都通過：2 筆直接釘證號（都有官方照片），3 筆縮到 2～3 個
        候選且其中有官方照片。

        安全量測（2026-09-30）：從全庫抽 1,908 張有中英品名的口服錠劑／
        膠囊藥證，各造五種藥袋寫法（品牌＋含量＋學名＋中文、加管制標記、
        加顏色等），這一層改變結果的 8,833 筆裡釘錯 0 筆、正確釘選 1,493
        筆、候選含正解 7,319 筆、候選不含正解 21 筆（藥證品名帶「(R)」
        這類正規化沒處理的字，只給候選不釘證號）。`looks_drug_related` 在
        23,037 句聊天訊息上的判定一句都沒變。

        三條規則，前兩條守住既有的證據標準：

        1. **每一段都必須自己通過驗證**（完全比對或 forward 含容命中，帶
           候選）。任何一段比不到就整個放棄——模型讀錯品牌時，不能靠同一串
           裡讀對的學名或劑型字眼過關；聊天訊息的探測字串也因此不會被一個
           碰巧是藥名的片段誤判成藥名。模糊命中不算：它不證明片段是真實品名。
        2. **只有某一段自己就唯一比到一張藥證時才釘證號**，而且各段投票的
           結果也只剩那一張。這一層不產生新的釘選能力，只是把能唯一定位的
           那一段從雜訊裡取出來。另外三種情況一律不釘、只給候選：丟掉過
           帶字的短片段（可能是「XL」「二號」這類版本字）、藥袋含量跟藥證
           品名上的含量對不上、學名段跟藥證主成分對不上。含量刻意只用來否決、
           不拿來收斂：模型把 40 讀成 20 時，收斂會釘到另一個劑量的藥並貼上
           它的照片；同名多張交給使用者拿實物比對照片挑選。
        3. **候選是得票最多的藥證**。劑型字（「膜衣錠」「TABLETS」）不投票，
           它只說明是錠劑，不說明是哪一顆；整串只剩劑型字時不算驗證通過，
           與 reverse-only 命中不建立驗證結果同一條理由。學名段也不投票：
           品名不一定印學名（「NEXIUM TABLETS 40MG」沒有 ESOMEPRAZOLE），用它
           投票會讓品名剛好帶學名的別家學名藥勝過原廠藥。整串除了劑型只有
           學名時才讓學名投票，結果等同直接拿學名去問。
        """
        segmentation = self._segments(name)
        if segmentation is None:
            return None
        segments = segmentation.segments
        if not segments or segments == [normalize_drug_name(name)]:
            return None

        results: list[tuple[str, DrugCatalogMatch]] = []
        for segment in segments:
            result = self._match_key(segment)
            if result is None or not result.candidates:
                return None
            results.append((segment, result))

        named = [(s, r) for s, r in results if s not in self._form_keys]
        brand = [(s, r) for s, r in named if s not in self._ingredient_keys]
        generic = [s for s, _ in named if s in self._ingredient_keys]
        voters = brand or named
        if not voters:
            return None

        votes: dict[str, int] = {}
        entries: dict[str, DrugCatalogEntry] = {}
        for _, result in voters:
            for entry in result.candidates:
                votes[entry.license_number] = votes.get(entry.license_number, 0) + 1
                entries.setdefault(entry.license_number, entry)
        top = max(votes.values())
        best = [entries[number] for number, count in votes.items() if count == top]
        score = min(result.score for _, result in voters)

        if len(best) == 1 and not segmentation.dropped_words:
            (entry,) = best
            pinned_by_a_segment = any(r.license_number == entry.license_number for _, r in voters)
            if (
                pinned_by_a_segment
                and self._agrees_with_generics(entry, generic)
                and not _strengths_conflict(segmentation.strengths_mg, entry)
            ):
                return DrugCatalogMatch(
                    license_number=entry.license_number,
                    name_zh=entry.name_zh,
                    name_en=entry.name_en,
                    score=score,
                    candidates=best,
                )
        return DrugCatalogMatch(
            license_number=None,
            name_zh="",
            name_en="",
            score=score,
            candidates=self._prefer_chinese_name(best, [segment for segment, _ in voters]),
        )

    @staticmethod
    def _prefer_chinese_name(
        best: list[DrugCatalogEntry], segments: list[str]
    ) -> list[DrugCatalogEntry]:
        """同票時，登記中文品名裡出現最多中文段的藥證優先。只縮小候選，不釘證號。

        盒子上的英文常是行銷名，不是登記的英文品名：普拿疼伏冒鼻炎感冒錠登記成
        PANADOL ALLERGY SINUS CAPLETS，盒子印 Panadol Cold & Flu Sinus。
        COLD、FLU 兩段替整個伏冒系列各投一票，正確那張靠中文段與 SINUS 才追平，
        2026-10-02 線上因此給了 11 個候選。

        比的是品名原文，不是比對鍵。量測（2026-10-02）：每張有中英品名的藥證造
        「中＋英」「英＋中」「中＋同品牌別張的英文」三種寫法。從中抽 10,000 張、
        26,752 筆時，用鍵比（中文段點得到就算）把正解刷掉 8 次——鍵拿掉了開頭
        引號裡的廠商名，`"巴斯夫" 泛醇` 的「巴斯夫」只點得到名字中段也有巴斯夫的
        別張；要求中文段逐字等於全名則刷掉 422 次——含量在分段時被拿掉，
        「氯黴素注射劑１２５ＭＧ/ＭＬ」切出的段剛好等於另一張沒寫含量的藥證。
        改比原文後全庫 66,418 張、177,899 筆：候選有變 10,177 筆、正解刷掉 0 次，
        「中＋同品牌別張的英文」那組候選總數 978,614 → 50,370。

        釘證號的判斷在呼叫端、用的是縮小前的票數，所以這一步不會讓任何原本
        不釘的藥被釘上：同票代表英文段不同意，仍交給使用者確認。沒有中文段、
        或每一張同票藥證點到的一樣多時原樣返回。
        """
        chinese = [segment for segment in segments if _CJK_RUN_RE.fullmatch(segment)]
        if len(best) < 2 or not chinese:
            return best

        def _hits(entry: DrugCatalogEntry) -> int:
            # 英文品名也看：少數藥證兩欄填反了（衛署藥輸字第026015號的 name_zh
            # 是 Lycadex PF、name_en 才是單水葡萄糖）。正常的英文品名沒有中文，
            # 多看一欄不影響其他藥證。
            text = unicodedata.normalize("NFKC", f"{entry.name_zh} {entry.name_en}").upper()
            runs = _CJK_RUN_RE.findall(text)
            return sum(any(segment in run for run in runs) for segment in chinese)

        hits = {entry.license_number: _hits(entry) for entry in best}
        top = max(hits.values())
        if top == 0:
            return best
        return [entry for entry in best if hits[entry.license_number] == top]

    @staticmethod
    def _agrees_with_generics(entry: DrugCatalogEntry, generic_segments: list[str]) -> bool:
        """藥袋上的學名是否都對得上這張藥證的主成分。沒有成分資料時不否決。"""
        if not generic_segments or not entry.ingredients:
            return True
        own = {normalize_drug_name(i) for i in entry.ingredients}
        own |= {normalize_drug_name(i.split(" ", 1)[0]) for i in entry.ingredients}
        return all(segment in own for segment in generic_segments)

    def _match_key(self, key: str) -> Optional[DrugCatalogMatch]:
        if not key or not self._by_key:
            return None

        exact = self._by_key.get(key)
        forward_hits: set[str] = set()
        reverse_hits: set[str] = set()
        if len(key) >= _MIN_CONTAINMENT_LENGTH:
            # 含容比對兩個方向的證據力不對稱，不能等量齊觀：
            # - forward（查詢是候選鍵的子字串）代表查詢字串整個對應到
            #   一張真實登記品名的一部分——這是「藥名真實存在」的證據
            #   （藥袋印短的品牌名，藥證是含劑型劑量的全名，見模組文件）。
            # - reverse（候選鍵是查詢字串的子字串）只代表某個登記過的
            #   片段剛好出現在查詢字串裡——任何字串只要恰好包含一個
            #   登記過的短詞（例如劑型名稱「膜衣錠」），不論是模型讀錯
            #   還是完全虛構的藥名，都會湊出這種命中。這不構成「查詢
            #   字串本身是真實藥名」的證據，見 `_reverse_containment_hits`
            #   與下方判斷式的說明。
            forward_hits = self._forward_containment_hits(key)
            reverse_hits = self._reverse_containment_hits(key)

        if exact is not None or forward_hits:
            # 已有完全比對或 forward 命中，藥名驗證為真：這時候把
            # reverse 命中一起聯集進來，只會「拆掉」原本看似唯一的
            # 答案（「潔毒注射液」命中「注射液」單獨掛證、「冠脂妥
            # 膜衣錠10毫克」命中「膜衣錠」單獨掛證都是這種情形），不會
            # 讓一個原本沒證據的查詢無中生有變成有證據——聯集只能讓
            # 候選變多，不能讓候選從 0 變成非 0。
            # 兩個方向要分開傳，不能在這裡先聯集成一份：reverse 只參與
            # 唯一性判定，不得進入可挑選的候選清單（模組文件「證據力」
            # 那條規則的第 2 半），兩份集合由 `_resolve` 分別承接。
            return self._resolve_exact_and_containment(key, exact, forward_hits, reverse_hits)

        if reverse_hits:
            # 唯一的命中訊號只有 reverse：查詢字串不對應任何真實登記
            # 的品名、也不是其中一部分，純粹是剛好包含了某個登記片段
            # （常見的是劑型名稱，或資料瑕疵留下的雜訊短鍵）。這不構成
            # 「藥名已驗證」的證據，必須維持未驗證、回傳 None，不得
            # 落入模糊比對——原本的判斷式本來就是「exact 或
            # 任一方向的含容命中非空」就不進模糊比對，這裡延續同一個
            # 控制流程，只是不再讓 reverse-only 的命中被誤判成已驗證。
            return None

        return self._match_by_fuzzy(key)

    def _candidates(self, key: str) -> set[str]:
        """從 gram 索引取候選鍵集合，含容比對與模糊比對共用同一份。

        交集（要求查詢字串的每個 gram 都出現在候選鍵的 gram 集合裡）
        精準對應「查詢字串是候選鍵的子字串」這個方向——這正是藥袋掃描
        最常見的情形（藥袋印短的品牌名，藥證是含劑型劑量的全名），且
        交集天生就小，不需要額外設上限。查詢裡完全查不到任何候選的
        gram（等同於「這串字跟藥證庫裡任何字串都沒有兩字重疊」）直接
        當作沒有貢獻、忽略，不讓它把交集清空成空集合——這只是放寬候選
        產生的精準度，之後含容比對仍會用真正的子字串關係驗證一次。

        另外聯集「查詢裡 postings 最少的那個 gram」，補上反方向（候選鍵
        是查詢字串的子字串）與模糊比對的召回率；設 postings 上限是為了
        不讓一個菜市場 gram 把候選集合撐回全庫規模。
        """
        grams = _ngrams(key)
        if not grams:
            return set()

        postings = [self._gram_index.get(gram, set()) for gram in grams]
        non_empty = [posting for posting in postings if posting]
        if not non_empty:
            return set()

        candidates = set.intersection(*non_empty) if len(non_empty) > 1 else set(non_empty[0])

        rarest = min(non_empty, key=len)
        if len(rarest) <= _MAX_RARE_GRAM_POSTINGS:
            candidates |= rarest

        return candidates

    def _reverse_containment_hits(self, key: str) -> set[str]:
        """精確找出全部「是查詢字串子字串」的鍵，不透過 gram 索引近似。

        這個方向沒有 gram 交集可用：候選鍵比查詢短，gram 數量本來就比
        查詢少，不可能涵蓋查詢的「每一個」gram。先前試過「聯集查詢裡
        （未超過頻率上限的）gram 的 postings」這個近似捷徑，仍然證明
        無法 provably 完整——候選鍵若自己的 gram 在全庫剛好都很常見
        （例如中文的「膜衣」「毫克」，或英文藥名裡到處都是的雙字母
        組合），就會被系統性地漏掉，且沒有一個長度上限能同時「涵蓋
        全部案例」又「窮舉集合夠小」（實測真實藥證庫裡單獨掛證的案例
        從 2 字的「膠囊」到 22 字的「TESTOSTERONEPROPIONATE」都有）。

        改用前綴分桶做精確多模式比對：候選鍵若真的從查詢字串某個位置
        開始逐字相同，它的前兩個字元必然等於查詢字串同一個位置的前
        兩個字元（`self._by_prefix` 正是用鍵的前兩個字元分桶）。所以
        對查詢字串的每一個起始位置，查一次分桶、對桶內候選逐一做切片
        比對確認是不是真的整段相同，就保證找到每一個真正的子字串候選，
        不必對全庫線性掃描——這是數學上的保證，不是機率上的近似。
        長度不足 2 字的鍵（`self._single_char_keys`）沒有完整的兩字
        前綴可分桶，另外在每個位置直接比對那一個字元。
        """
        hits: set[str] = set()
        length = len(key)
        for start in range(length):
            if key[start] in self._single_char_keys:
                hits.add(key[start])
            prefix = key[start : start + 2]
            if len(prefix) < 2:
                continue
            for candidate_key in self._by_prefix.get(prefix, ()):
                if key[start : start + len(candidate_key)] == candidate_key:
                    hits.add(candidate_key)
        return hits

    def _forward_containment_hits(self, key: str) -> set[str]:
        """找出「查詢是候選鍵的子字串」這個方向的候選鍵。

        由 `_candidates(key)` 的 gram 交集完整覆蓋——候選鍵必然含有
        查詢的每一個 gram，見該方法的說明。這個方向代表查詢字串整個
        對應到某個真實登記品名的一部分，是「藥名真實存在」的證據，
        跟 `_reverse_containment_hits` 只能用來拆掉唯一性、不能單獨
        建立驗證結果的地位不同，見 `match()` 的判斷式。
        """
        return {candidate_key for candidate_key in self._candidates(key) if key in candidate_key}

    def _resolve_exact_and_containment(
        self,
        key: str,
        exact: Optional[dict[str, DrugCatalogEntry]],
        forward_hits: Iterable[str],
        reverse_hits: Iterable[str],
    ) -> DrugCatalogMatch:
        """把三種命中攤平成「唯一性集合」與「可挑選集合」兩份。

        見 spec「證號唯一才可信」與 DrugCatalogMatch 的說明：完全比對
        精準命中一個鍵不代表消除了歧義，三種訊號要聯集之後才能交給
        `_resolve` 判定唯一性。命中鍵可能不只一個（「普拿疼」同時是
        三個品名的子字串），每個命中鍵本身也可能已經是碰撞鍵——都要
        攤平進同一份集合，唯一性判定才不會漏看任何一張藥證。

        但唯一性判定的集合不等於拿給使用者挑的集合：reverse 命中按
        定義是**別的藥**（只是碰巧有個登記過的片段落在查詢字串裡），
        它足以拆掉唯一性，卻不能當成「你吃的可能是這一顆」讓使用者
        挑——挑中就會貼上那顆藥的照片。因此這裡建兩份字典，
        `entries_by_license` 決定 `license_number`，`pickable_by_license`
        決定 `candidates`，兩者的差集正好是 reverse-only 的命中。
        理由與量測見模組文件「證據力」那一段。
        """
        forward_keys = set(forward_hits)
        reverse_keys = set(reverse_hits)

        entries_by_license: dict[str, DrugCatalogEntry] = {}
        for candidate_key in forward_keys | reverse_keys:
            entries_by_license.update(self._by_key[candidate_key])
        pickable_by_license: dict[str, DrugCatalogEntry] = {}
        for candidate_key in forward_keys:
            pickable_by_license.update(self._by_key[candidate_key])

        if exact is not None:
            entries_by_license.update(exact)
            # 完全比對是「查詢字串本身就是這張藥證的品名」，是三種命中裡
            # 證據力最強的一種，當然可挑。
            pickable_by_license.update(exact)
            # 完全比對存在時 score 固定 1.0（字串確實逐字相同），不論
            # 聯集後候選是不是唯一——這正是 score 1.0 不再等於證號確定
            # 的地方，由 `_resolve` 依候選數量決定 license_number。
            return self._resolve(entries_by_license.values(), 1.0, pickable_by_license.values())

        if len(entries_by_license) > 1:
            # 沒有完全比對、純靠含容比對湊出多張藥證：藥名驗證為真，
            # 但無法判斷是哪一張——理由見 DrugCatalogMatch 的說明。
            # score 沒有另外定義的意義，這裡不是相似度比對，留 0.0
            # 只是滿足型別。
            return self._resolve(entries_by_license.values(), 0.0, pickable_by_license.values())

        (entry,) = entries_by_license.values()
        # 含容覆蓋率：兩字串長度比值，短字串完全落在長字串裡時最高為 1.0。
        # 純粹供除錯／記錄參考，比對邏輯本身不看這個分數。兩個方向的命中
        # 都算進來（跟切分候選之前一樣），這個分數不參與任何判定。
        coverage = max(
            min(len(key), len(candidate_key)) / max(len(key), len(candidate_key))
            for candidate_key in forward_keys | reverse_keys
            if entry.license_number in self._by_key[candidate_key]
        )
        return self._resolve(entries_by_license.values(), coverage, pickable_by_license.values())

    def _match_by_fuzzy(self, key: str) -> Optional[DrugCatalogMatch]:
        candidates = self._candidates(key)
        if not candidates:
            return None

        # 先選出相似度最高的「鍵」，再取該鍵對應的全部藥證當候選——
        # 挑鍵的邏輯跟原本一樣（第一個嚴格超過目前最高分的才換），只是
        # 命中的鍵本身可能對應不只一張藥證，唯一性判定交給 `_resolve`。
        best_key: Optional[str] = None
        best_score = 0.0
        for candidate_key in candidates:
            score = SequenceMatcher(None, key, candidate_key).ratio()
            if score > best_score:
                best_key, best_score = candidate_key, score

        if best_key is None or best_score < self._threshold:
            return None
        # 模糊命中只證明「這個字串很像某個真實藥名」，不證明「這個字串**是**
        # 一個真實藥名」——它在藥證庫裡一個字面命中都沒有。依模組文件開頭
        # 那條同樣的規則（沒有證明查詢字串是真實品名的命中，不得用來確定
        # 身分），這裡一律不釘證號、也不帶候選：
        # - 不釘證號：量測方式是拿全庫 56,886 個中文品名當母體，固定亂數
        #   種子抽 6,000 筆，把正規化鍵裡的一個字換掉，再走完整條 match()
        #   控制流程，算「不設此限時會釘上的證號屬於別顆藥」的比率（spec
        #   「模糊比對只驗證藥名，不確定身分」記的是同一次量測）：
        #     替換一個**中文字**：0.18%（11/6,000）不論同分的哪一個鍵勝出
        #     都會釘到別顆藥，另有 0.15% 要看勝出的是哪一個，合計 0.33%。
        #     例：'安融寧錠2毫克'（真實品名 '安保寧錠２毫克' 換掉「保」）
        #     → '"約克"安寧錠2毫克'（衛署藥製字第038370號），score 0.923。
        #     替換一個**劑量數字**：0.48%（29/6,000）必然釘錯；連同視勝出
        #     者而定的同分案例，合計**約 2%**——這個合計刻意不寫到小數點
        #     第二位：它計入的正是同分案例，而同分誰勝出取決於下面那句話
        #     講的 set 迭代順序，同一份資料在不同行程量到的就是不同的數字
        #     （實測 PYTHONHASHSEED 0／1／42 分別落在 2.02%／2.00%／2.02%），
        #     寫成一個定值會讓讀者以為它可重現。比中文字高，因為同一個
        #     品名家族的不同劑量彼此只差一個數字。
        #     例：'思樂康持續性藥效錠30毫克'（真實品名 '思樂康持續性藥效錠
        #     50 毫克' 換掉劑量數字）→ '思樂康持續性藥效錠 300 毫克'
        #     （衛署藥輸字第024886號），score 0.963——同廠牌，劑量差 10 倍。
        #   兩個例子都確認過真的走得到這裡（查詢字串不是任何鍵，forward 與
        #   reverse 命中皆為空），且最高分只有一個鍵拿到，不受上面挑鍵時
        #   set 迭代順序的影響。「合計」與「必然」的差額就是同分的案例：
        #   最高分由多個鍵並列時，上面的迴圈只留「第一個嚴格更高分」的那個，
        #   誰勝出取決於 set 的迭代順序——同一個查詢在不同行程可能釘到不同
        #   藥證，連錯得穩不穩定都談不上。
        #   逐行程的變異不只出在這裡的分數同分，上游的候選池本身就會變：
        #   `_candidates` 的 `min(non_empty, key=len)` 在多個 gram 的 postings
        #   長度並列時，選到哪一個取決於 `_ngrams` 回傳的 set 的迭代順序，
        #   聯集進去的就是不同的集合（實測抽樣 4,000 筆查詢有 824 筆存在這種
        #   並列，PYTHONHASHSEED 0／1／42／7 的候選池**成員**四次皆不同——池的
        #   大小恰好相同，所以只比大小會漏看）。
        #   但這個不確定性到不了任何真實藥名：全庫 56,886 個中文品名跑完
        #   `match()`，釘定證號與完整候選清單在 PYTHONHASHSEED 0／1／42／7
        #   下位元相同（pinned 皆為 19,204）。會受影響的只有字面上比不到任何
        #   鍵、因而落到這裡的查詢，而這條路徑本來就一律不釘證號——變動的是
        #   「這個錯字還救不救得回來」，不是「救回來的是哪一顆藥」。
        #   證號一釘就解析得出縮圖，推播與
        #   清單會貼上一張錯的藥丸照片，而畫面上沒有任何東西能讓長輩發現
        #   不對——貼錯照片比不貼照片危險。
        # - 不帶候選：候選機制的安全性建立在「候選皆受藥名約束，錯的候選
        #   仍是同名藥品」（design.md 的 Risks），使用者是在同名藥品之間
        #   挑。模糊路徑上的候選按定義就是**別的藥名**，這個前提不成立，
        #   不能拿來給使用者挑。
        # 名稱驗證完全不受影響：`_verify_against_catalog` 只看 `match()`
        # 是否為 None（prescription_scan_service.py），模糊比對回收錯讀
        # 藥名的能力原封不動保留，這裡放掉的只有「是哪一張藥證」。
        return DrugCatalogMatch(
            license_number=None, name_zh="", name_en="", score=best_score, candidates=[]
        )

    @staticmethod
    def _resolve(
        entries: Iterable[DrugCatalogEntry],
        score: float,
        pickable: Iterable[DrugCatalogEntry],
    ) -> DrugCatalogMatch:
        """把「命中鍵對應到的藥證集合」收斂成一筆比對結果。

        這是唯一決定 `license_number` 有沒有值的地方——證號是否確定只看
        `entries` 的數量是不是剛好 1，跟走的是哪個階段、score 是多少無關。

        `entries` 與 `pickable` 是**兩個不同的角色**，刻意分成兩個參數而
        不是一份集合兼任：

        - `entries`：唯一性判定用。包含 reverse 命中——它證據力不足以
          指認身分，卻足以證明「還有別的可能」，漏掉它會回傳一個錯的
          確定證號。
        - `pickable`：`candidates` 的來源，也就是畫面上會出現、使用者
          挑中就會貼上藥丸照片的清單。不含 reverse-only 的命中。

        `pickable` 沒有預設值是刻意的：預設成 `entries` 會讓任何新的
        呼叫端在忘記切分時，悄悄地把「別的藥」放回可挑清單，而這個
        退化沒有任何測試以外的地方看得出來（照片一貼上去，畫面上不會
        有東西反駁它）。要兩者相同就明講兩次。

        `entries` 唯一時 `pickable` 必然等於 `entries`：走到這裡的前提是
        exact 或 forward 命中非空（見 `match()` 的判斷式），所以 `pickable`
        非空，而 `pickable ⊆ entries`——「已釘證號卻沒有候選」這個狀態
        不可能出現。反過來不成立：`pickable` 剩一筆時 `entries` 可能仍有
        多筆，此時證號留空、候選只有一筆，由使用者確認才釘定
        （見 LIFF 的 `DrugCandidateSection`）。
        """
        entries = list(entries)
        candidates = list(pickable)
        if len(entries) == 1:
            (entry,) = entries
            return DrugCatalogMatch(
                license_number=entry.license_number,
                name_zh=entry.name_zh,
                name_en=entry.name_en,
                score=score,
                candidates=candidates,
            )
        return DrugCatalogMatch(
            license_number=None, name_zh="", name_en="", score=score, candidates=candidates
        )
