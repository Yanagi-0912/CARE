import asyncio
import logging
import re
from typing import Any

from langchain_core.documents import Document

from app.core.request_logging import stage_timer
from app.core.user_language import get_request_language
from app.services.gemini import GeminiService
from app.i18n.messages import t
from app.services.rag.cannot_answer import (
    CANNOT_ANSWER_MARKERS,
    NO_ANSWER_SENTINEL,
    answer_preview,
    matched_cannot_answer_marker,
)
from app.services.rag.answer_prompts import build_rag_prompt, wrap_context
from app.services.rag.cohere_reranker import Reranker, VectorScoreReranker
from app.services.rag.link_check import LinkChecker, dead_urls
from app.core.publish_date import format_publish_date
from app.core.rag_sources import SourceRef, set_request_rag_sources
from app.services.rag.fail_messages import (
    NO_ANSWER_MESSAGE,
    NO_HITS_MESSAGE,
    RagFailCode,
    rag_fail,
)
from app.services.rag.query_rewriter import QueryRewriter, RewrittenQuery
from app.services.rag.question_decomposer import (
    QuestionDecomposer,
    SubQuestion,
    looks_compound,
)
from app.services.rag.retrieval_grader import Grade, RetrievalGrader
from app.services.rag.retriever import MongoAtlasVectorRetriever
from app.services.rag.web_search_service import WebSearchService
from app.services.gemini.shared.parser import content_to_text

logger = logging.getLogger(__name__)

# Wide retrieve candidates（依賴注入可用 settings 覆寫 retriever.k）
RETRIEVAL_TOP_K = 40
RERANK_TOP_N = 5
CITE_TOP_K = 3
# 精排後之文章層級去重：同一篇文章最多留幾個 chunk（見 dedup_ranked_docs）
RERANK_MAX_CHUNKS_PER_ARTICLE = 2
# CRAG grader 失敗時的數值門檻。0.0＝不設限，維持原行為。
#
# 正常路徑的相關性把關全靠 CRAG（grader 判 incorrect 就轉網搜），而
# RAG_VECTOR_MIN_SCORE 預設是 0.0——也就是說整條管線沒有任何數值下限。
# grader 本身逾時或配額用盡時，既有的降級是「不分級直接生成」，於是一組
# 可能毫不相關的 chunk 會被拿去生成醫療答案，而 prompt 裡「內容不足請說
# 不知道」只是軟約束。
#
# 這個門檻只在 grader 失敗那條路徑上生效，正常路徑不受影響——不是要用
# 數字取代 CRAG，是在 CRAG 不可用時補一張網。
DEFAULT_DEGRADED_MIN_SCORE = 0.0

# 投機生成：CRAG 分級期間先把生成跑起來。
#
# 分級與生成互不依賴——生成只吃 ranked，分級不改動它——所以兩者可以並行。
# 實測分級 2.6-7.0s、生成 3.9-9.5s，而 84% 的題目分級結果是 correct、
# 送去生成的 docs 原封不動，這時等於整段分級時間白賺。
#
# 代價是另外 16%（incorrect／ambiguous）會多一次白跑的生成，付的是 token
# 不是延遲，並讓單次請求的 Gemini 併發從 1 升到 2。要關掉設 false。
DEFAULT_SPECULATIVE_GENERATE = True

# 整條管線的總逾時（秒）。0＝不設限。
#
# 為什麼需要：各段各自有逾時（Cohere、Firecrawl、連結檢查），但加起來沒有上限；
# Gemini 的呼叫以前根本沒有逾時（langchain-google-genai 4.2.2 預設 timeout=None、
# 重試 6 次；2026-09-16 起由 gemini_service 統一設 GEMINI_REQUEST_TIMEOUT_SECONDS
# 與重試 2 次，但單次上限×重試次數仍大於這裡的總預算）。實測過 rag_retrieve
# 卡 94 秒才回 0 筆，使用者等 107 秒換一句「查無資料」。檢索那段另有每條腿的
# 逾時（retriever.DEFAULT_LEG_TIMEOUT_SECONDS），這裡是最後一道：不管卡在哪一段，
# 到點就停。
#
# 45 秒的來由：
#   - 上界：LINE loading 動畫最長 60 秒（官方文件：「5 to 60 seconds」），超過
#     使用者連「還在處理」都看不到。60 秒要分給 RAG 以外的段落：guardrail＋
#     agent 決策＋最終回覆實測合計約 5 秒（2026-09-02）；語音回覆的 TTS 沒量過
#     （上限是連線 5＋接收 15 秒）。這裡留 15 秒給它們。
#   - 下界：golden 55 題完整管線（2026-09-14，本機 gemini-3.8-flash，各 1 次）
#     最慢 18.7 秒（網搜路徑），p90 14.9 秒。45 秒是最慢那題的 2.4 倍，正常
#     題目不會被切掉。
#
# 到點回 [RAG_ERR:TIMEOUT]，agent 依 prompt 規則 10 請使用者稍後再問。
DEFAULT_RAG_ANSWER_TIMEOUT_SECONDS = 45.0

_CITATION_RE = re.compile(r"\[(\d+)\]")

# 複合問題拆題只處理繁中：拆題 prompt 與已驗證的使用情境只涵蓋 zh-TW。
COMPOUND_LANGUAGE = "zh-TW"


def cited_indices(answer_text: str) -> list[int]:
    """回傳答案中出現過的引用編號，依首次出現順序、去重。"""
    seen: set[int] = set()
    order: list[int] = []
    for match in _CITATION_RE.finditer(answer_text or ""):
        idx = int(match.group(1))
        if idx not in seen:
            seen.add(idx)
            order.append(idx)
    return order


class RagAnswerService:
    def __init__(
        self,
        gemini_service: GeminiService,
        retriever: MongoAtlasVectorRetriever,
        reranker: Reranker | None = None,
        *,
        rerank_top_n: int = RERANK_TOP_N,
        max_chunks_per_article: int = RERANK_MAX_CHUNKS_PER_ARTICLE,
        grader: RetrievalGrader | None = None,
        rewriter: QueryRewriter | None = None,
        crag_enabled: bool = False,
        web_search: WebSearchService | None = None,
        web_fallback_enabled: bool = False,
        degraded_min_score: float = DEFAULT_DEGRADED_MIN_SCORE,
        link_checker: LinkChecker | None = None,
        speculative_generate: bool = DEFAULT_SPECULATIVE_GENERATE,
        total_timeout_seconds: float = DEFAULT_RAG_ANSWER_TIMEOUT_SECONDS,
        decomposer: QuestionDecomposer | None = None,
    ) -> None:
        self.gemini_service = gemini_service
        self.retriever = retriever
        self.reranker: Reranker = reranker or VectorScoreReranker()
        self.rerank_top_n = rerank_top_n
        self.max_chunks_per_article = max_chunks_per_article
        self.grader = grader
        self.rewriter = rewriter
        self.crag_enabled = crag_enabled and grader is not None
        self.web_search = web_search
        self.web_fallback_enabled = bool(web_fallback_enabled and web_search is not None)
        self.degraded_min_score = degraded_min_score
        # None＝不檢查來源網址存活，行為與導入前完全相同（見 link_check.py）
        self.link_checker = link_checker
        # 只有 CRAG 開啟時才有東西可以並行——沒有分級就沒有等待可以填。
        self.speculative_generate = bool(speculative_generate and self.crag_enabled)
        self.total_timeout_seconds = total_timeout_seconds
        # None＝不拆複合問題（RAG_COMPOUND_DECOMPOSE_ENABLED=false），行為與導入前相同
        self.decomposer = decomposer

    async def answer(self, user_text: str, *, original_message: str | None = None) -> str:
        """*original_message* 是本輪使用者原文，只有 `get_rag_answer` 會傳。

        有原文且看起來是複合問題時才嘗試拆題（見 `_answer_compound`）；其餘呼叫端
        （藥單問答、主張查核）不傳，查詢裡的附加內容就不會被拆題改寫掉。
        """
        # 總計時的 path 欄位標出這一輪實際走了哪條路——同樣是 40 秒，
        # 走 kb 與走 web 要查的地方完全不同。
        with stage_timer(logger, "rag_answer") as timing:
            limit = self.total_timeout_seconds if self.total_timeout_seconds > 0 else None
            deadline = asyncio.timeout(limit)
            try:
                async with deadline:
                    return await self._answer(user_text, timing, original_message)
            except TimeoutError:
                # 只接自己這個總逾時。管線裡別處拋出的 TimeoutError 是另一種
                # 故障，照舊往上拋——記成「逾時」會把查錯方向帶歪。
                if not deadline.expired():
                    raise
                return self._timed_out(timing)

    def _timed_out(self, timing: dict[str, Any]) -> str:
        """總逾時到點：記錄、清掉已交出的來源，回 TIMEOUT。

        進行中的投機生成與改寫已由 `_answer` 的 finally 取消（逾時是以取消
        送進去的），這裡不必再收。
        """
        # 不能留在原本的 path：記成 kb 會讓分流門檻的校準把它當成「這個分數帶
        # 知識庫答得出來」的樣本（理由同 kb_model_refuse）。last_path 記逾時
        # 當下走到哪條路，才分得出卡在知識庫還是網搜。
        timing["last_path"] = timing.get("path")
        timing["path"] = "timeout"
        # 網搜路徑可能已把來源交給呈現層才逾時，逾時訊息不能掛著那組按鈕。
        set_request_rag_sources(())
        logger.warning(
            "rag_fail code=%s timeout_s=%s last_path=%s",
            RagFailCode.TIMEOUT,
            self.total_timeout_seconds,
            timing["last_path"],
        )
        return rag_fail(RagFailCode.TIMEOUT)

    async def _answer(
        self, user_text: str, timing: dict[str, Any], original_message: str | None = None
    ) -> str:
        if self._should_try_compound(original_message):
            assert original_message is not None
            compound = await self._answer_compound(original_message, timing)
            if compound is not None:
                return compound
        timing["path"] = "kb"
        # candidates＝第一輪的 docs；approved＝CRAG 放行的 docs。兩者刻意用不同
        # 名字：投機生成是否可用，正是靠「這兩個是不是同一個 list」判斷的。
        candidates = await self._retrieve_and_rerank(user_text)
        # 精排最高分，供日後校準「CRAG 之前就分流到網搜」的門檻：對照最後走
        # kb 答出來與 web_crag_reject 的題目各落在哪個分數帶。為什麼不用問題
        # 文字訓練分類器——知識庫持續新增，分類器學到的是舊知識庫的覆蓋範圍，
        # 而被它送去網搜的題目永遠不會再碰知識庫、日誌也永遠記 web，重新訓練
        # 只會把錯誤鎖得更死。這個分數是每次從知識庫即時算出的，沒有這個問題。
        timing["top_rerank"] = self._top_rerank_score(candidates)
        if not candidates:
            timing["path"] = "web_empty_retrieval"
            return await self._web_or_no_hits(user_text)

        speculative = self._start_speculative_generate(user_text, candidates)
        rewrite = self._start_speculative_rewrite(user_text, candidates)
        link_prefetch = self._start_link_prefetch(candidates)
        try:
            return await self._answer_from(
                user_text, candidates, speculative, rewrite, link_prefetch, timing
            )
        finally:
            # 冪等：正常路徑上任務已被 await，這裡不做事；提早 return 或例外
            # 逃出時才真正收掉，不留 orphan task。CRAG 放行時改寫結果用不到
            # （改寫現在只給網搜用），也是在這裡被取消。
            _abandon_task(speculative)
            _abandon_task(rewrite)
            # 死鏈預查不取消、讓它自己跑完（有總預算兜著）：取消會讓
            # `_check_many` 在子任務還在跑時關掉 httpx client，噴一堆與這題
            # 無關的例外；跑完的結果還會進快取，下一題引用同一來源時省一輪。
            _let_finish(link_prefetch)

    async def _answer_from(
        self,
        user_text: str,
        candidates: list[Document],
        speculative: "asyncio.Task[str] | None",
        rewrite: "asyncio.Task[RewrittenQuery] | None",
        link_prefetch: "asyncio.Task[frozenset[str]] | None",
        timing: dict[str, Any],
    ) -> str:
        approved: list[Document] | None = candidates
        if self.crag_enabled:
            try:
                approved = await self._apply_crag(user_text, candidates)
            except Exception:
                logger.exception(
                    "CRAG failed; degrading to generate without grade crag_grade=degraded"
                )
                # CRAG 是這條路徑唯一的相關性把關，它失效時不能就這樣放行。
                # 精排分數是這裡唯一還可信的訊號（Cohere 的 relevance_score
                # 有明確語意；降級到 VectorScoreReranker 時則是融合後的排名
                # 分數）。過不了門檻就走與「知識庫無資料」相同的路徑——
                # 寧可少答，不要拿不相關的內容生成醫療答案。
                timing["path"] = "kb_crag_degraded"
                approved = self._filter_by_degraded_score(candidates)
                if not approved:
                    logger.info("rag_fail code=%s crag_grade=degraded_below_floor",
                                RagFailCode.KB_EMPTY)
                    timing["path"] = "web_degraded_below_floor"
                    _abandon_task(speculative)
                    return await self._web_or_no_hits(user_text, rewrite)
            else:
                if approved is None:
                    timing["path"] = "web_crag_reject"
                    # 這裡就收掉投機生成，不要留到 `_answer` 的 finally——網搜
                    # 那段要跑 5~15 秒，留著等於讓一份確定不會用的 KB 生成整個
                    # 跑完。2026-09-16 實測 5 題有 3 題走這條路，每題白燒一次
                    # 2.9-7.4 秒的完整生成。牆鐘時間省不到（它本來就是並行的
                    # task），省的是 Gemini 的 token。
                    #
                    # 只是盡力而為：請求已經在路上，取消關掉的是連線，供應商那
                    # 端已經生成的 token 仍可能照算。
                    _abandon_task(speculative)
                    return await self._web_or_no_hits(user_text, rewrite)

        kb_answer = await self._resolve_generate(
            speculative, user_text, candidates, approved
        )
        ranked = approved
        if self._is_cannot_answer(kb_answer):
            marker = matched_cannot_answer_marker(kb_answer, CANNOT_ANSWER_MARKERS)
            preview = answer_preview(kb_answer)
            logger.info(
                "rag_fail code=%s matched_marker=%s answer_preview=%s",
                RagFailCode.MODEL_REFUSE,
                marker,
                preview,
            )
            # 不能留在 path=kb：這一題知識庫其實沒答出來，記成 kb 會讓分流門檻
            # 的校準把它當成「這個分數帶知識庫答得出來」的樣本，門檻被往下拉。
            # path 要在轉網搜之前就定下來：網搜那段不改 path，校準樣本才會留在
            # kb_model_refuse 這一格，與 web_crag_reject 分得開。
            timing["path"] = "kb_model_refuse"
            if self.web_fallback_enabled:
                # 與「知識庫沒命中」「CRAG 判不相關」走同一條路：知識庫有文件但
                # 模型判定答不出來，對使用者來說一樣是「官方網站還沒查過」。以前
                # 這裡直接回 MODEL_REFUSE 叫使用者換個說法，而 CRAG 判 incorrect
                # 的題目反而會去網搜——同一種「知識庫答不了」，兩條路待遇不同。
                return await self._web_or_no_hits(user_text, rewrite)
            return rag_fail(RagFailCode.MODEL_REFUSE)

        dead = await self._dead_source_urls(kb_answer, ranked, timing, link_prefetch)
        return self._append_sources(kb_answer, ranked, dead)

    def _should_try_compound(self, original_message: str | None) -> bool:
        return (
            self.decomposer is not None
            and looks_compound(original_message)
            and get_request_language() == COMPOUND_LANGUAGE
        )

    async def _answer_compound(self, message: str, timing: dict[str, Any]) -> str | None:
        """複合問題：逐子問題檢索、分級，只把通過的子問題交給生成。

        回傳 None＝放棄拆題，由呼叫端走現行流程（含 Web Fallback）。放棄的情況：
        不是複合問題、拆題或分級失敗、所有子問題都沒通過、生成只寫出拒答標記。
        也就是說這條路只在「至少一個子問題以知識庫答得出」時接手，其餘與現況相同。

        設計取捨都是 2026-09-27～30 的離線實驗量出來的（design.md 決策 3～7）：
          - 子問題只用自己的候選，不做原句那一路檢索：原句會撈進謠言文擠掉
            子問題的相關文件（T05 Q1 合併池 9/9 ambiguous，只用自己的候選 3/3 correct）
          - 檢索用 retrieval_query、分級與生成用 question：分級維持「能不能回答
            這位使用者的情況」這個嚴格標準，不因拆題而放寬
          - 生成不給原句：看得到原句時，模型會替沒通過的子問題也寫一段，或因為
            原句裡有答不了的部分而整段寫拒答標記
          - 沒通過的子問題由程式補固定句：交給模型寫，它會寫成拒答標記拖垮整題
        日誌只記數量，不記原文（原文是病史與家人狀況，理由同 Agent.invoke）。
        """
        assert self.decomposer is not None
        try:
            with stage_timer(logger, "rag_decompose") as t_decompose:
                subs = await self.decomposer.decompose(message)
                t_decompose["subs"] = len(subs)
        except Exception:
            logger.exception("compound_decompose_failed; falling back to single-question path")
            return None
        if len(subs) < 2:
            return None

        timing["path"] = "kb_compound"
        timing["subs"] = len(subs)
        ranked_by_sub = await asyncio.gather(
            *(self._retrieve_and_rerank(sub.retrieval_query) for sub in subs)
        )
        try:
            supported = await self._grade_sub_questions(subs, ranked_by_sub)
        except Exception:
            logger.exception("compound_crag_failed; falling back to single-question path")
            return None
        timing["supported"] = sum(supported)
        if not any(supported):
            logger.info("rag_compound fallback=none_supported subs=%d", len(subs))
            return None

        evidence = self._interleave_evidence(
            [docs for docs, ok in zip(ranked_by_sub, supported) if ok]
        )
        answered = [sub.question for sub, ok in zip(subs, supported) if ok]
        raw = await self._generate_answer(_compound_generation_question(answered), evidence)
        if self._is_cannot_answer(raw):
            if not cited_indices(raw):
                logger.info("rag_compound fallback=model_refuse subs=%d", len(subs))
                return None
            # 有引用的段落是答得出來的內容；標記是模型對其中某一段的保留，不能
            # 讓它把整段答案判成拒答。
            raw = raw.replace(NO_ANSWER_SENTINEL, "").strip()

        unanswered = [sub.question for sub, ok in zip(subs, supported) if not ok]
        body = raw.strip()
        if unanswered:
            notes = "\n".join(
                t("rag.compound_unsupported").format(question=q) for q in unanswered
            )
            body = f"{body}\n\n{notes}"
        logger.info(
            "rag_compound subs=%d supported=%d evidence=%d",
            len(subs),
            len(answered),
            len(evidence),
        )
        dead = await self._dead_source_urls(body, evidence, timing)
        return self._append_sources(body, evidence, dead)

    async def _grade_sub_questions(
        self, subs: list[SubQuestion], ranked_by_sub: list[list[Document]]
    ) -> list[bool]:
        """嚴格分級：只有 correct 算通過（與單題路徑同一標準）。CRAG 關閉時有文件就算。"""
        if not self.crag_enabled:
            return [bool(docs) for docs in ranked_by_sub]
        assert self.grader is not None

        async def _one(sub: SubQuestion, docs: list[Document]) -> bool:
            if not docs:
                return False
            return await self.grader.grade(sub.question, docs) is Grade.CORRECT

        with stage_timer(logger, "rag_crag_grade", subs=len(subs)):
            return list(
                await asyncio.gather(*(_one(s, d) for s, d in zip(subs, ranked_by_sub)))
            )

    def _interleave_evidence(self, lists: list[list[Document]]) -> list[Document]:
        """各子問題的精排結果輪流取用，總數不超過 rerank_top_n；同一 chunk 只收一次。

        輪流而不是全域排序：全域 top-n 可能被某個子問題的文件佔滿，另一個子問題
        一篇都分不到——那正是拆題要避免的「漏答其中一件事」。
        """
        evidence: list[Document] = []
        seen: set[tuple[str, str]] = set()
        depth = 0
        longest = max((len(docs) for docs in lists), default=0)
        while len(evidence) < self.rerank_top_n and depth < longest:
            for docs in lists:
                if depth < len(docs) and len(evidence) < self.rerank_top_n:
                    doc = docs[depth]
                    key = (self._source_key(doc), doc.page_content)
                    if key not in seen:
                        seen.add(key)
                        evidence.append(doc)
            depth += 1
        return evidence

    @staticmethod
    def _top_rerank_score(docs: list[Document]) -> float | None:
        """候選中最高的 Cohere `rerank_score`；沒有任何一篇帶這個鍵時回傳 None。

        只認 `rerank_score`：Cohere 的 relevance_score 是絕對校準的相關性分數，
        跨題可比；融合分數是逐題正規化或只看名次的分數，跨題比較沒有意義，拿來
        訂所有題目共用的門檻不成立。Cohere 失效時回傳 None，日誌就不輸出這個
        欄位（`_format_kv` 略過 None）——「沒有分數」必須與「分數很低」分得開，
        否則校準時會把 Cohere 失效的題目誤當成低分樣本。
        """
        scores = [
            float(raw)
            for doc in docs
            if isinstance(raw := doc.metadata.get("rerank_score"), (int, float))
        ]
        return round(max(scores), 4) if scores else None

    def _filter_by_degraded_score(self, docs: list[Document]) -> list[Document]:
        """只保留 Cohere `rerank_score` 達到門檻的文件。門檻為 0 時原樣回傳。

        **只認 `rerank_score`，不退回 `score`。** 沒有這個欄位就代表 Cohere
        也失效了（`VectorScoreReranker` 不寫這個鍵），此時整批視為不合格，
        走與「知識庫無資料」相同的路徑。

        為什麼不退回 `score`——這是量出來的，不是設計偏好。以 golden set 的
        22 題、110 篇降級路徑候選（36 相關／74 不相關）實測
        （`scripts/rag_degraded_floor_scan.py`）：

          - 融合分數（convex α=0.6）：相關文件均值 0.632、不相關 0.650。
            **不相關的比相關的還高**，中位數同向（0.606 / 0.619）。原因是
            min-max 是逐題正規化的，每題該腿的第一名恆為 1.0——「整批候選
            都不相關」的那一題，它最好的那筆照樣滿分。而這張網要擋的正是
            整批不相關的情況，正規化剛好把唯一有用的訊號抹掉。
          - 原始 cosine：相關 0.8941、不相關 0.8872，差 0.0069，分佈完全
            重疊（相關最低 0.854 < 不相關的 p75 0.897）。門檻在 0.05~0.80
            之間只會刷掉那 3 筆「BM25 撈到但向量沒撈到」的文件——那不是
            相關性過濾，是關掉 BM25 那條腿；拉到 0.90 才開始有效果，代價是
            一次丟掉 9 題的相關文件。

        也就是說這兩個尺度上都不存在有意義的門檻值。`rerank_score` 不同：
        Cohere 的 relevance_score 是絕對校準的分數，0.3 在它上面才有語意。

        另一個好處是這讓門檻與 `RAG_FUSION_MODE` 解耦。退回 `score` 時，
        RRF（兩腿滿分也才 1/61+1/61 ≈ 0.033）與凸組合（0~1）在同一個 0.3
        之下的行為天差地遠——切換融合模式會順帶改到醫療答案的把關，那是
        兩件不該綁在一起的事。

        行為變更的範圍（其餘情況與本次變更前完全相同）：只有「Cohere 不可用
        **且** 走純向量檢索（RAG_HYBRID_ENABLED=false）」這個組合會改變——
        該組合下 `score` 是 cosine（≈0.88 > 0.3），過去會放行，現在轉網搜。
        依上述量測，那個放行本來就近似「什麼都沒擋」；要維持舊行為請把
        `RAG_DEGRADED_MIN_SCORE` 設為 0，那也更誠實地描述它實際在做的事。
        """
        if self.degraded_min_score <= 0:
            return docs
        kept: list[Document] = []
        for doc in docs:
            raw = doc.metadata.get("rerank_score")
            if isinstance(raw, (int, float)) and float(raw) >= self.degraded_min_score:
                kept.append(doc)
        return kept

    async def _web_or_no_hits(
        self,
        query: str,
        rewrite: "asyncio.Task[RewrittenQuery] | None" = None,
    ) -> str:
        if not self.web_fallback_enabled or self.web_search is None:
            return self._fail(RagFailCode.KB_EMPTY)
        try:
            with stage_timer(logger, "rag_web_fallback"):
                search_queries = await self._search_queries_for_web(query, rewrite)
                if search_queries is None:
                    return await self.web_search.answer(query)
                return await self.web_search.answer(
                    query, search_queries=search_queries
                )
        except Exception:
            logger.exception("web fallback failed")
            return self._fail(RagFailCode.WEB_ERROR)

    def _start_speculative_rewrite(
        self, user_text: str, docs: list[Document]
    ) -> "asyncio.Task[RewrittenQuery] | None":
        """在 CRAG 分級開始前就把查詢改寫排進事件迴圈。

        改寫結果只有兩條路用得到：分級判 ambiguous（kb_query 重查知識庫）與
        判 incorrect（zh_terms／en_terms 網搜）。兩者都要等分級結束才知道，
        而改寫不依賴分級結果，所以與分級並行。2026-09-12 實測改寫（thinking
        low）1.2-3.3 秒、分級 1.6-3.7 秒：多數情況改寫先跑完，網搜路徑不必
        多等；ambiguous 路徑則省下原本排在分級之後的整段改寫。

        代價是分級判 correct 時這次改寫白跑（投機生成那段註解記錄過 84% 的
        題目判 correct），付的是 token 不是延遲，單次請求的 Gemini 併發也再多 1。
        """
        if not (self.crag_enabled and self.rewriter is not None):
            return None
        return asyncio.create_task(
            self._timed_rewrite(user_text, docs, speculative=True)
        )

    async def _timed_rewrite(
        self, user_text: str, docs: list[Document], *, speculative: bool
    ) -> RewrittenQuery:
        assert self.rewriter is not None
        # speculative 欄位的理由同 rag_generate：並行那次的 ms 與分級重疊，
        # 不能直接和序列的階段相加。
        with stage_timer(logger, "rag_crag_rewrite", speculative=speculative or None):
            return await self.rewriter.rewrite(user_text, docs)

    async def _await_rewrite(
        self,
        rewrite: "asyncio.Task[RewrittenQuery] | None",
        user_text: str,
        docs: list[Document],
    ) -> RewrittenQuery:
        """取用並行中的改寫；沒有並行任務時（例如檢索為空）當場改寫。

        `rag_rewrite_wait` 記的是分級結束後還得等改寫多久——這才是改寫讓
        使用者多等的時間，接近 0 代表被分級完全蓋掉。
        """
        if rewrite is None:
            return await self._timed_rewrite(user_text, docs, speculative=False)
        with stage_timer(logger, "rag_rewrite_wait"):
            return await rewrite

    async def _search_queries_for_web(
        self,
        user_text: str,
        rewrite: "asyncio.Task[RewrittenQuery] | None",
    ) -> RewrittenQuery | None:
        """網搜要用的改寫查詢。改寫失敗回 None，網搜退回用原句，不中斷回答。"""
        if self.rewriter is None:
            return None
        try:
            return await self._await_rewrite(rewrite, user_text, [])
        except Exception:
            logger.exception(
                "query rewrite failed; web search falls back to the original question"
            )
            return None

    @staticmethod
    def _fail(code: str) -> str:
        logger.info("rag_fail code=%s", code)
        return rag_fail(code)

    async def _retrieve_and_rerank(self, query: str) -> list[Document]:
        with stage_timer(logger, "rag_retrieve") as t_retrieve:
            docs = await self.retriever.ainvoke(query)
            t_retrieve["docs"] = len(docs)
        if not docs:
            return []
        # 拿完整排序（不是只拿 top_n）：文章層級去重必須看過全部候選才能
        # 判斷「這篇文章還有沒有更高分的 chunk 沒被算進去」，只截斷後的
        # top_n 會讓去重看不到被擠掉的候選，等於沒去重。
        with stage_timer(
            logger, "rag_rerank", docs_in=len(docs)
        ) as t_rerank:
            ranked = await self.reranker.rerank(query, docs, top_n=len(docs))
            t_rerank["docs_out"] = len(ranked)
        deduped = dedup_ranked_docs(ranked, max_per_article=self.max_chunks_per_article)
        return deduped[: self.rerank_top_n]

    async def _apply_crag(
        self, user_text: str, ranked: list[Document]
    ) -> list[Document] | None:
        """回傳可用於生成的 docs；None 表示知識庫不足、改走網搜。

        只分一次級。以前 `ambiguous` 會再跑一輪「改寫 → 重新檢索精排 → 再分
        一次級」，2026-09-16 實測那一輪要 8.7 秒（改寫 5.5 + 第二次分級 3.2），
        而最慢的那題跑完第二輪仍是 ambiguous、照樣落到網搜——20.2 秒裡有 8.7
        秒買了一個沒有改變結論的判斷。

        `ambiguous` 現在與 `incorrect` 同樣直接走網搜。grader 對 ambiguous 的
        語意是「有關但資訊不足」，而「資訊不足」正是網搜要補的東西；先前那條
        「預算用完就拿第一輪 ranked 硬生成」的路等於在知識庫不足時仍從知識庫
        生成，方向與這個判斷相反。
        """
        assert self.grader is not None
        with stage_timer(logger, "rag_crag_grade") as t_grade:
            grade = await self.grader.grade(user_text, ranked)
            t_grade["grade"] = grade.value
        logger.info("crag_grade=%s", grade.value)

        return ranked if grade is Grade.CORRECT else None

    @staticmethod
    def _build_context(docs: list[Document]) -> str:
        """組出帶編號與出處標頭的 context。

        標頭只放 source_name 與 original_title，**不放 url** —— url 進 context
        會佔 token，且模型可能改寫或杜撰網址。url 由 `_append_sources`
        依編號對應回填。

        發布日期有值時一併放進標頭。prompt 刻意**不**加「引用舊資料要加註
        提醒」這類規則：答案有字數上限（ANSWER_MAX_CHARS），強制加註會排擠
        掉衛教內容本身，而「多舊算舊」在沒有實測之前只是憑感覺定的門檻。
        這裡只是把日期交到模型手上，讓它在問題本身就與時間有關時（「現在的
        規定」「最新公告」）有東西可依據。
        """
        blocks: list[str] = []
        for idx, doc in enumerate(docs, start=1):
            parts: list[str] = []
            source = str(doc.metadata.get("source_name") or "").strip()
            title = str(doc.metadata.get("original_title") or "").strip()
            published_at = RagAnswerService._doc_published_at(doc)
            if source:
                parts.append(f"來源：{source}")
            if title:
                parts.append(f"標題：{title}")
            if published_at:
                parts.append(f"發布日期：{published_at}")
            header = f"[{idx}]" + (f" {'｜'.join(parts)}" if parts else "")
            blocks.append(f"{header}\n{doc.page_content}")
        return "\n\n".join(blocks)

    def _start_speculative_generate(
        self, user_text: str, docs: list[Document]
    ) -> "asyncio.Task[str] | None":
        """在 CRAG 分級開始前就把生成排進事件迴圈。"""
        if not self.speculative_generate:
            return None
        return asyncio.create_task(
            self._generate_answer(user_text, docs, speculative=True)
        )

    async def _resolve_generate(
        self,
        speculative: "asyncio.Task[str] | None",
        user_text: str,
        candidates: list[Document],
        approved: list[Document],
    ) -> str:
        """取用投機結果，或丟棄後以放行的 docs 重新生成。

        判斷用 identity（`approved is candidates`）而非內容比對：CRAG 判
        `correct` 時原封不動回傳同一個 list，走改寫第二輪時回的是另一個
        list，降級過濾有門檻時也會建新 list——identity 恰好把「送去生成的
        docs 有沒有被換掉」問乾淨。

        重點是判錯的方向：identity 為假但內容其實相同時，只是白重生一次，
        慢一點而已；**不可能**發生「拿未經放行的 docs 生成的答案回給使用
        者」。這個不對稱是本最佳化能碰醫療答案的前提。
        """
        if speculative is None:
            return await self._generate_answer(user_text, approved)
        if approved is candidates:
            logger.info("speculative_generate=hit")
            return await speculative
        logger.info("speculative_generate=miss")
        _abandon_task(speculative)
        return await self._generate_answer(user_text, approved)

    async def _generate_answer(
        self, question: str, docs: list[Document], *, speculative: bool = False
    ) -> str:
        context = self._build_context(docs)
        messages = build_rag_prompt().format_messages(
            question=question, context=wrap_context(context)
        )
        # speculative 欄位是必要的：投機那次與分級並行，它的 ms 會與
        # rag_crag_grade 重疊，直接拿去和序列版本相加會重複計算。
        with stage_timer(
            logger, "rag_generate", docs=len(docs), speculative=speculative or None
        ):
            rag_result = await self.gemini_service.chat_model.ainvoke(messages)
        # `content_to_text` 而非 `str()`：Gemini 開著 thinking 時 `.content`
        # 回的是 list-of-parts（`[{"type": "text", "text": "…", "extras":
        # {"signature": "<數千字 base64>"}}]`），`str()` 會把整個 Python
        # repr 連同簽章一起變成「答案」。實測一則 400 字的衛教回覆會被包成
        # 4,600~7,000 字，之後全程當作答案文字傳遞——進 agent 的 context、
        # 進引用解析、也會進卡片。
        # 模型回空字串就是答不出來，直接給拒答標記。原本退回
        # rag.generate_fallback（「抱歉，我目前找不到相關資料」），再靠字眼比對
        # 轉成拒答；拒答改成只認標記後，那段文案會被當成答案送出去。
        answer_text = content_to_text(rag_result.content) or NO_ANSWER_SENTINEL
        return answer_text

    @staticmethod
    def _is_cannot_answer(text: str) -> bool:
        return (
            matched_cannot_answer_marker(text, CANNOT_ANSWER_MARKERS) != "<none>"
        )

    @staticmethod
    def _doc_url(doc: Document) -> str:
        return str(doc.metadata.get("url") or "").strip()

    @staticmethod
    def _doc_published_at(doc: Document) -> str:
        """這份文件的發布日期，正規化成 `YYYY-MM-DD`；沒有或解析不出來回空字串。

        解析不出來就當成沒有（見 `format_publish_date`）：庫裡這個欄位是各
        scraper 原樣寫入的，混著佔位字串與抽錯欄位的值，照樣印出去等於宣稱
        那是發布日期。
        """
        return format_publish_date(doc.metadata.get("published_at"))

    @staticmethod
    def _cited_urls(answer_text: str, docs: list[Document]) -> list[str]:
        """只取答案真的引用到的那幾筆的網址，依引用順序、去重。

        來源清單只列被引用的 doc，所以只有這幾筆的存活狀態會影響輸出。
        預查（`_start_link_prefetch`）雖然把全部候選都查過，最後仍只拿這
        幾筆的結果。
        """
        urls: list[str] = []
        seen: set[str] = set()
        for idx in cited_indices(answer_text):
            if idx < 1 or idx > len(docs):
                continue
            url = RagAnswerService._doc_url(docs[idx - 1])
            if not url or url in seen:
                continue
            seen.add(url)
            urls.append(url)
        return urls

    def _start_link_prefetch(
        self, candidates: list[Document]
    ) -> "asyncio.Task[frozenset[str]] | None":
        """在分級／生成還在跑的時候就先查候選來源的網址活不活。

        以前是生成完、知道引用了哪幾筆才查，於是整段檢查（線上 14 天 p50
        0.87 秒、p90 2.6 秒、最差 6.5 秒）直接加在生成之後。候選是誰在檢索
        精排完就定了，生成只會從裡面挑；先把全部候選查起來，生成完只剩讀結果。

        代價是多查沒被引用的那幾筆——候選最多 `rerank_top_n`（預設 5）筆，
        多出的 HTTP 往返與被它們佔掉的快取位置都很小。
        """
        if self.link_checker is None:
            return None
        urls: list[str] = []
        seen: set[str] = set()
        for doc in candidates:
            url = self._doc_url(doc)
            if url and url not in seen:
                seen.add(url)
                urls.append(url)
        if not urls:
            return None
        return asyncio.create_task(dead_urls(self.link_checker, urls))

    async def _dead_source_urls(
        self,
        answer_text: str,
        docs: list[Document],
        timing: dict[str, Any],
        link_prefetch: "asyncio.Task[frozenset[str]] | None" = None,
    ) -> frozenset[str]:
        """判定哪些被引用的網址現在打不開。關閉或失敗時回空集合。

        有預查任務時取它的結果再篩出被引用的；`checked` 仍記被引用的筆數，
        `prefetched` 標出這一筆的等待時間是「預查剩下的尾巴」而不是整段檢查。
        """
        if self.link_checker is None:
            return frozenset()
        urls = self._cited_urls(answer_text, docs)
        if not urls:
            return frozenset()
        with stage_timer(
            logger,
            "rag_link_check",
            checked=len(urls),
            prefetched=True if link_prefetch is not None else None,
        ) as lc_timing:
            if link_prefetch is not None:
                try:
                    dead_all = await link_prefetch
                except Exception:
                    # `dead_urls` 自己就會把例外吃掉回空集合；走到這裡是任務
                    # 層級的故障（例如被取消），同樣退回「全部照常顯示」。
                    logger.exception("link_prefetch_failed; showing all sources unchecked")
                    dead_all = frozenset()
                dead = frozenset(url for url in urls if url in dead_all)
            else:
                dead = await dead_urls(self.link_checker, urls)
            lc_timing["dead"] = len(dead)
        if dead:
            # 記下實際被降級的網址：這是 link rot 的唯一可觀測訊號，也是
            # 之後要不要回頭清庫（重新 ingest 或下架該來源）的依據。
            logger.info(
                "citation_link_dead count=%d urls=%s", len(dead), sorted(dead)
            )
        timing["dead_citations"] = len(dead)
        return dead

    @staticmethod
    def _source_label(doc: Document, url: str | None = None) -> str | None:
        """來源顯示字串；無 url 時退回「來源名｜標題」，兩者皆無則回 None。

        *url* 為 None 時取 metadata 原值。呼叫端會在網址判定為打不開時改傳
        空字串——把「死掉的 url」完全等同於「沒有 url」，既有的退回邏輯就
        原封不動地變成降級路徑，不需要新增一種顯示分支。

        有發布日期時接在來源名後面，寫法與查核判定卡一致（「（YYYY-MM-DD
        發布）」）；沒有來源名就不標日期——單獨一個日期掛在網址前面看不出
        是什麼的日期。
        """
        source = str(doc.metadata.get("source_name") or "").strip()
        url = RagAnswerService._doc_url(doc) if url is None else url.strip()
        title = str(doc.metadata.get("original_title") or "").strip()
        published_at = RagAnswerService._doc_published_at(doc)
        if source and published_at:
            source = f"{source}（{published_at} 發布）"
        if url:
            return f"{source}：{url}" if source else url
        if title:
            return f"{source}｜{title}" if source else title
        return None

    @staticmethod
    def _source_key(doc: Document, url: str | None = None) -> str:
        """判定「同一個來源」的鍵；有 url 用 url，否則用來源名＋標題。

        *url* 的語意同 `_source_label`。傳空字串進來時去重會退回
        「來源名＋標題」，與這筆來源在顯示上的身分保持一致——顯示成同一行
        的兩筆，去重也必須把它們當成同一筆。
        """
        url = RagAnswerService._doc_url(doc) if url is None else url.strip()
        if url:
            return f"url:{url}"
        source = str(doc.metadata.get("source_name") or "").strip()
        title = str(doc.metadata.get("original_title") or "").strip()
        return f"meta:{source}|{title}"

    @staticmethod
    def _source_ref(doc: Document, index: int, url: str | None = None) -> SourceRef:
        """從 metadata 直接取值組成結構化來源。

        刻意不重用 `_source_label` 的輸出：那個字串是給純文字清單看的，
        用全形冒號把來源名與網址黏在一起，而來源名本身也可能含冒號，
        反解回來不可靠。
        """
        source = str(doc.metadata.get("source_name") or "").strip()
        title = str(doc.metadata.get("original_title") or "").strip()
        url = RagAnswerService._doc_url(doc) if url is None else url.strip()
        label = source or title or f"來源 {index}"
        # 日期分成獨立欄位而不是併進 label：呈現層要自己決定放不放得下
        # （Flex 按鈕的文字會被截斷，純文字清單不會）。
        return SourceRef(
            index=index,
            label=label,
            url=url,
            published_at=RagAnswerService._doc_published_at(doc),
        )

    @staticmethod
    def _append_sources(
        answer_text: str,
        docs: list[Document],
        dead_urls: frozenset[str] = frozenset(),
    ) -> str:
        """組出來源清單。*dead_urls* 中的網址一律降級為「不顯示網址」。

        存活檢查本身在 `_dead_source_urls` 做完才進來，這個函式維持純函式
        性質（同一組輸入永遠組出同一個輸出），網路 I/O 不混進呈現邏輯裡。
        預設空集合＝完全是導入檢查前的行為。

        降級不是丟棄：該筆來源仍佔一個編號、仍出現在清單裡，只是退回
        「來源名｜標題」而沒有網址，呈現層也就不會給它一顆點了打不開的
        按鈕。這符合 rag-responses「缺 url 不得靜默丟棄」——答案本文的
        引用標記指得到東西，使用者也看得到我們依據的是哪個機構的資料。
        """
        cited = cited_indices(answer_text)
        if not cited:
            logger.info("citation_missing docs=%d", len(docs))
            set_request_rag_sources(())
            return answer_text

        key_to_new: dict[str, int] = {}
        renumber: dict[int, int] = {}
        source_lines: list[str] = []
        source_refs: list[SourceRef] = []

        for old_idx in cited:
            if old_idx < 1 or old_idx > len(docs):
                continue
            doc = docs[old_idx - 1]
            raw_url = RagAnswerService._doc_url(doc)
            url = "" if raw_url in dead_urls else raw_url
            label = RagAnswerService._source_label(doc, url)
            if label is None:
                # 網址死了、又沒有來源名與標題可退回，這筆就真的無從顯示。
                # 與導入前「metadata 全空」走的是同一條路徑。
                continue
            key = RagAnswerService._source_key(doc, url)
            existing = key_to_new.get(key)
            if existing is not None:
                renumber[old_idx] = existing
                continue
            if len(source_lines) >= CITE_TOP_K:
                continue
            new_idx = len(source_lines) + 1
            key_to_new[key] = new_idx
            renumber[old_idx] = new_idx
            source_lines.append(f"[{new_idx}] {label}")
            # 與文字清單同一個迴圈、同一個 new_idx，兩者編號因此不可能漂移。
            source_refs.append(RagAnswerService._source_ref(doc, new_idx, url))

        def _replace(match: re.Match[str]) -> str:
            mapped = renumber.get(int(match.group(1)))
            return f"[{mapped}]" if mapped is not None else ""

        # 先改寫內文再決定要不要附清單：即使一筆來源都解析不出來，
        # 那些指向不存在來源的標記仍必須從答案中移除。
        body = _CITATION_RE.sub(_replace, answer_text)

        if not source_lines:
            logger.info("citation_unresolved cited=%s docs=%d", cited, len(docs))
            set_request_rag_sources(())
            return body

        set_request_rag_sources(source_refs)
        heading = t("agent.sources_heading")
        return f"{body}\n\n{heading}\n" + "\n".join(source_lines)


def _abandon_task(task: "asyncio.Task[str] | None") -> None:
    """收掉不再需要的投機任務。冪等，可安全重複呼叫。

    已完成且帶例外時要主動取出例外，否則 asyncio 會噴
    "Task exception was never retrieved"——那條路上的失敗本來就要丟棄，
    不該變成 log 噪音。
    """
    if task is None or task.cancelled():
        return
    if not task.done():
        task.cancel()
        return
    task.exception()


def _let_finish(task: "asyncio.Task | None") -> None:
    """放掉一個不再需要結果、但也不值得取消的任務。

    只掛一個取例外的 callback：任務自己跑完，失敗也不會變成
    "Task exception was never retrieved" 的噪音。
    """
    if task is None or task.done():
        _abandon_task(task)
        return
    task.add_done_callback(_consume_task_exception)


def _consume_task_exception(task: "asyncio.Task") -> None:
    if not task.cancelled():
        task.exception()


def dedup_ranked_docs(
    docs: list[Document], *, max_per_article: int
) -> list[Document]:
    """精排後之文章層級去重：同一篇文章最多留 max_per_article 個 chunk。

    *docs* 必須已依相關性排序（分數高在前，例如 reranker 的完整排序結果）；
    本函式只依序掃描並過濾超出上限的 chunk，**不重新排序**，因此保留的
    chunk 之間相對順序與輸入一致。

    文章身分判定沿用 `RagAnswerService._source_key`（有 url 用 url，無 url
    用 source_name+original_title），不重新發明身分邏輯，確保與
    `_append_sources` 判斷「同一來源」的邏輯一致。

    `max_per_article < 1` 視為 1（至少保留每篇文章的最高分 chunk），不拋例外。
    """
    cap = max_per_article if max_per_article >= 1 else 1
    counts: dict[str, int] = {}
    out: list[Document] = []
    for doc in docs:
        key = RagAnswerService._source_key(doc)
        count = counts.get(key, 0)
        if count >= cap:
            continue
        counts[key] = count + 1
        out.append(doc)
    return out


def _compound_generation_question(questions: list[str]) -> str:
    """拆題路徑送進 RAG prompt 的「使用者問題」欄位：只列通過的子問題、不含原句。"""
    lines = [
        "請只回答下列問題，每個問題各自一段，每段開頭用「關於（簡短主題）：」標出在回答哪個問題，"
        "不要回答或提及清單以外的問題："
    ]
    lines += [f"{i}. {q}" for i, q in enumerate(questions, start=1)]
    return "\n".join(lines)
