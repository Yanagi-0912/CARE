from app.tools.claim_tools import is_claim_tool_configured, verify_claim
from app.tools.family_directory_tools import get_family_directory
from app.tools.knowledge_report_tools import submit_knowledge_report
from app.tools.medical_tools import (
    find_nearby_facilities_by_department,
    find_nearby_hospitals,
    lookup_medical_facility,
    request_location_quick_reply,
)
from app.tools.medication_question_tools import ask_about_my_medications
from app.tools.medication_report_tools import record_medication_taken
from app.tools.medication_status_tools import get_medication_status
from app.tools.official_site_tools import open_official_site
from app.tools.rag_tools import get_rag_answer
from app.tools.share_tools import share_care
from app.tools.symptom_tools import suggest_department_for_symptom
from app.tools.tv_news_tools import (
    ask_tv_news_channel,
    is_tv_news_tool_configured,
    verify_tv_news,
)
from app.tools.user_document_tools import answer_from_uploaded_document


def get_all_tools(include_rag_tool: bool = True) -> list:
    """回傳 Langchain Tool。"""
    tools = [
        find_nearby_hospitals,
        find_nearby_facilities_by_department,
        lookup_medical_facility,
        request_location_quick_reply,
        submit_knowledge_report,
        open_official_site,
        # 分享 CARE 給朋友、邀請家人。跟知識庫無關，同樣不隨 include_rag_tool 開關。
        share_care,
        # 與院所搜尋同屬醫療工具，不隨 include_rag_tool 開關——「我肚子痛要掛
        # 哪一科」問的是掛號科別而非查知識庫，guardrail 是否放行 RAG 與這件事
        # 無關。
        suggest_department_for_symptom,
        # 查本人或家人的服藥狀況。查的是資料庫裡的紀錄、不是知識庫，同樣不隨
        # include_rag_tool 開關——guardrail 放不放行 RAG 與這件事無關。
        get_medication_status,
        # 只查登入者自己的家庭名單與稱謂，不讀健康資料，也不隨 RAG 開關。
        get_family_directory,
        # 在聊天裡回報「我吃過了」。寫的是自己的服藥紀錄、不碰知識庫，
        # 同樣不隨 include_rag_tool 開關。
        record_medication_taken,
    ]
    if include_rag_tool:
        # `ask_about_my_medications` 內部就是跑 RAG（只是把藥名附在問題後面），
        # 所以跟著 include_rag_tool 開關——guardrail 沒放行知識庫時，它也不該
        # 成為繞過去的第二個入口。
        tools.extend(
            [get_rag_answer, answer_from_uploaded_document, ask_about_my_medications]
        )
        # verify_claim 與 get_rag_answer 同屬「guardrail 放行後才提供」的知識庫
        # 工具，因此跟著 include_rag_tool 一起開關；是否配置服務（即
        # CLAIM_VERIFICATION_ENABLED 這道獨立開關的結果，見
        # is_claim_tool_configured 的說明）是另一層過濾，兩者皆為真才提供，
        # 不新增第二個布林參數（YAGNI）。
        if is_claim_tool_configured():
            tools.append(verify_claim)
        # 電視新聞畫面專用的查核（判定卡多一顆「看新聞原文」）。與
        # verify_claim 同一道開關，因為它們用的是同一個查核服務。
        if is_tv_news_tool_configured():
            tools.extend([verify_tv_news, ask_tv_news_channel])

    return tools
